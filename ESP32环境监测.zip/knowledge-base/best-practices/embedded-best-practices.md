# 嵌入式开发最佳实践

## 1. 代码规范

### 命名规范

```c
// 变量命名: 小驼峰
float temperatureValue;
int sensorPin;

// 常量命名: 全大写+下划线
#define MAX_RETRY_COUNT 3
const int LED_PIN = 2;

// 函数命名: 小驼峰，动词开头
void initSensor();
float readTemperature();
bool isWiFiConnected();

// 结构体命名: 大驼峰
typedef struct {
    float temperature;
    float humidity;
    float light;
} SensorData;
```

### 代码组织

```c
// 1. 头文件包含
#include <Arduino.h>
#include "config.h"

// 2. 宏定义
#define DEBUG_ENABLED 1

// 3. 类型定义
typedef struct { ... } MyStruct;

// 4. 全局变量
static int globalVar = 0;

// 5. 函数声明
void setup();
void loop();

// 6. 函数实现
void setup() { ... }
void loop() { ... }
```

## 2. 内存管理

### 避免内存碎片

```c
// 错误: 频繁分配释放
void bad_example() {
    char *buffer = malloc(100);
    // 使用 buffer
    free(buffer);
}

// 正确: 使用静态缓冲区
static char buffer[100];
void good_example() {
    // 直接使用 buffer
}
```

### 使用 F() 宏

```c
// 错误: 字符串占用 RAM
Serial.println("Hello World");

// 正确: 字符串存储在 Flash
Serial.println(F("Hello World"));
```

### 监控内存使用

```c
void printMemoryInfo() {
    Serial.printf("Free heap: %d bytes\n", ESP.getFreeHeap());
    Serial.printf("Min free heap: %d bytes\n", ESP.getMinFreeHeap());
    Serial.printf("Max alloc: %d bytes\n", ESP.getMaxAllocHeap());
}
```

## 3. 错误处理

### 检查返回值

```c
bool initSensor() {
    if (!sensor.begin()) {
        Serial.println(F("[ERROR] Sensor init failed"));
        return false;
    }
    return true;
}

void setup() {
    if (!initSensor()) {
        // 错误处理
        while (1) {
            delay(1000);
        }
    }
}
```

### 看门狗保护

```c
#include <esp_task_wdt.h>

void setup() {
    // 初始化看门狗，超时时间 5 秒
    esp_task_wdt_init(5, true);
    esp_task_wdt_add(NULL);
}

void loop() {
    // 喂狗
    esp_task_wdt_reset();

    // 业务逻辑
    doWork();

    delay(10);
}
```

### 异常恢复

```c
void robustOperation() {
    int retryCount = 0;
    const int MAX_RETRIES = 3;

    while (retryCount < MAX_RETRIES) {
        if (performOperation()) {
            return; // 成功
        }

        retryCount++;
        Serial.printf("[WARN] Retry %d/%d\n", retryCount, MAX_RETRIES);
        delay(1000 * retryCount); // 指数退避
    }

    Serial.println("[ERROR] Operation failed after retries");
    // 降级处理
}
```

## 4. 电源管理

### 低功耗模式

```c
#include <esp_sleep.h>

void enterDeepSleep(int seconds) {
    Serial.printf("[INFO] Entering deep sleep for %d seconds\n", seconds);
    esp_sleep_enable_timer_wakeup(seconds * 1000000);
    esp_deep_sleep_start();
}

void enterLightSleep(int seconds) {
    Serial.printf("[INFO] Entering light sleep for %d seconds\n", seconds);
    esp_sleep_enable_timer_wakeup(seconds * 1000000);
    esp_light_sleep_start();
}
```

### 外设电源控制

```c
void disableUnusedPeripherals() {
    // 禁用蓝牙
    btStop();

    // 禁用 WiFi
    WiFi.mode(WIFI_OFF);

    // 降低 CPU 频率
    setCpuFrequencyMhz(80);
}
```

## 5. 通信协议

### I2C 最佳实践

```c
void initI2C() {
    Wire.begin(SDA_PIN, SCL_PIN);
    Wire.setClock(100000); // 100kHz 标准模式
}

bool i2cScan() {
    byte count = 0;
    for (byte addr = 1; addr < 127; addr++) {
        Wire.beginTransmission(addr);
        if (Wire.endTransmission() == 0) {
            Serial.printf("[INFO] I2C device found at 0x%02X\n", addr);
            count++;
        }
    }
    return count > 0;
}
```

### SPI 最佳实践

```c
void initSPI() {
    SPI.begin(SCK_PIN, MISO_PIN, MOSI_PIN, CS_PIN);
    SPI.setFrequency(1000000); // 1MHz
    SPI.setDataMode(SPI_MODE0);
}
```

### UART 最佳实践

```c
void initUART() {
    Serial.begin(115200);
    Serial.setTimeout(1000); // 超时 1 秒
}

void sendCommand(const char* cmd) {
    Serial.println(cmd);
    Serial.flush(); // 等待发送完成
}
```

## 6. 调试技巧

### 串口调试

```c
#if DEBUG_ENABLED
    #define DEBUG_PRINT(x) Serial.print(x)
    #define DEBUG_PRINTLN(x) Serial.println(x)
    #define DEBUG_PRINTF(fmt, ...) Serial.printf(fmt, ##__VA_ARGS__)
#else
    #define DEBUG_PRINT(x)
    #define DEBUG_PRINTLN(x)
    #define DEBUG_PRINTF(fmt, ...)
#endif
```

### LED 指示

```c
void blinkLED(int times, int delayMs) {
    for (int i = 0; i < times; i++) {
        digitalWrite(LED_PIN, HIGH);
        delay(delayMs);
        digitalWrite(LED_PIN, LOW);
        delay(delayMs);
    }
}

// 错误指示
void indicateError() {
    blinkLED(3, 200);
}

// 成功指示
void indicateSuccess() {
    blinkLED(1, 1000);
}
```

### 断言

```c
#include <assert.h>

void criticalOperation() {
    assert(sensorValue > 0 && "Sensor value must be positive");
    assert(buffer != NULL && "Buffer cannot be NULL");
    // ...
}
```

## 7. 安全考虑

### 输入验证

```c
bool validateInput(const char* input, int maxLength) {
    if (input == NULL) return false;
    if (strlen(input) > maxLength) return false;
    // 检查特殊字符
    for (int i = 0; input[i]; i++) {
        if (input[i] < 32 || input[i] > 126) {
            return false;
        }
    }
    return true;
}
```

### 安全字符串操作

```c
// 错误: 缓冲区溢出风险
char buffer[10];
strcpy(buffer, user_input);

// 正确: 使用安全函数
char buffer[10];
strlcpy(buffer, user_input, sizeof(buffer));
```

## 8. 性能优化

### 避免浮点运算

```c
// 错误: 浮点运算慢
float temp = readSensor() * 1.8 + 32.0;

// 正确: 整数运算
int temp = (readSensor() * 18 + 320) / 10;
```

### 使用查表法

```c
// 错误: 实时计算
float sinValue = sin(angle);

// 正确: 查表
const float SIN_TABLE[] = {0.0, 0.1, 0.2, ...};
float sinValue = SIN_TABLE[index];
```

### 批量操作

```c
// 错误: 逐个发送
for (int i = 0; i < 100; i++) {
    Serial.print(data[i]);
}

// 正确: 批量发送
Serial.write(data, 100);
```
