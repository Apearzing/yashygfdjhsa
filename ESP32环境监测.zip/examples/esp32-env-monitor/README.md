# ESP32 智能环境监测系统

## 项目简介

基于 ESP32 的智能环境监测系统，用于实时采集温湿度、光照、空气质量等环境数据，并通过 WiFi 上传至云平台。

## 功能特性

- 温湿度监测 (DHT22)
- 光照强度监测 (BH1750)
- 空气质量监测 (MQ-135)
- OLED 显示屏实时显示
- WiFi 数据上传
- 串口调试输出

## 硬件清单

| 元器件 | 型号 | 数量 | 参考价格 |
|--------|------|------|---------|
| 主控板 | ESP32-DevKitC-32D | 1 | ¥35 |
| 温湿度传感器 | DHT22 | 1 | ¥12 |
| 光照传感器 | BH1750 | 1 | ¥8 |
| 空气质量传感器 | MQ-135 | 1 | ¥15 |
| OLED 显示屏 | SSD1306 0.96寸 | 1 | ¥15 |
| 面包板 | 830孔 | 1 | ¥10 |
| 杜邦线 | 公对母 | 20 | ¥5 |
| **总计** | | | **¥100** |

## 接线图

```
ESP32          DHT22
------         ------
3.3V  ------>  VCC
GPIO4 ------>  DATA
GND   ------>  GND

ESP32          BH1750
------         ------
3.3V  ------>  VCC
GPIO21 ------>  SDA
GPIO22 ------>  SCL
GND   ------>  GND

ESP32          SSD1306
------         ------
3.3V  ------>  VCC
GPIO21 ------>  SDA
GPIO22 ------>  SCL
GND   ------>  GND
```

## 快速开始

### 1. 环境准备

安装 Arduino IDE 或 PlatformIO

### 2. 安装库

```bash
# PlatformIO
pio lib install "DHT sensor library"
pio lib install "BH1750"
pio lib install "Adafruit SSD1306"

# Arduino IDE
# 通过库管理器安装上述库
```

### 3. 配置 WiFi

编辑 `config.h`，修改 WiFi 配置：

```c
#define WIFI_SSID "your_ssid"
#define WIFI_PASS "your_password"
```

### 4. 编译烧录

```bash
# PlatformIO
pio run -t upload

# Arduino IDE
# 打开 main.ino，选择开发板 ESP32 Dev Module，点击上传
```

### 5. 查看输出

打开串口监视器，波特率设置为 115200：

```
[INFO] System starting...
[INFO] DHT sensor initialized
[INFO] BH1750 sensor initialized
[INFO] WiFi connected
[INFO] IP: 192.168.1.100
[INFO] System initialized
[DATA] Temp: 25.5°C, Hum: 60.2%, Light: 350.0lux
[DATA] Temp: 25.6°C, Hum: 60.1%, Light: 345.0lux
```

## 演示流程

1. **系统启动**: 上电后等待 WiFi 连接
2. **数据采集**: 观察传感器数据输出
3. **显示界面**: 查看 OLED 显示内容
4. **数据上传**: 确认数据成功上传云端
5. **异常处理**: 测试传感器断开后的错误处理

## 性能指标

| 指标 | 数值 |
|------|------|
| 数据采集频率 | 1次/5秒 |
| WiFi 连接时间 | <10秒 |
| 内存使用 | <50% |
| 运行稳定性 | >24小时 |

## 常见问题

### Q1: 传感器读数异常

- 检查接线是否正确
- 确认传感器供电正常
- 检查 I2C 地址是否冲突

### Q2: WiFi 连接失败

- 确认 SSID 和密码正确
- 检查 WiFi 信号强度
- 尝试重启开发板

### Q3: 串口无输出

- 检查串口波特率设置
- 确认 USB 线连接正常
- 尝试按复位按钮

## 许可证

MIT License
