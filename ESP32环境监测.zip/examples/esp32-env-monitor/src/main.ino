// ============================================
// ESP32 智能环境监测系统 - 主程序
// 生成时间: 2026-05-06 10:00:08
// ============================================

#include <Arduino.h>
#include <WiFi.h>
#include <DHT.h>
#include <BH1750.h>
#include <Adafruit_SSD1306.h>

// 配置定义
#define WIFI_SSID "your_ssid"
#define WIFI_PASS "your_password"
#define SERIAL_BAUD 115200
#define UPDATE_INTERVAL 5000

// 引脚定义
#define DHT_PIN 4
#define SDA_PIN 21
#define SCL_PIN 22
#define LED_PIN 2

// OLED 配置
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1

// 全局对象
DHT dht(DHT_PIN, DHT22);
BH1750 lightSensor;
Adafruit_SSD1306 display(SCREEN_WIDTH, SCREEN_HEIGHT, &Wire, OLED_RESET);

// 全局变量
unsigned long lastUpdate = 0;
bool wifiConnected = false;

void setup() {
    Serial.begin(SERIAL_BAUD);
    Serial.println("[INFO] System starting...");

    // 初始化 LED
    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);

    // 初始化 I2C
    Wire.begin(SDA_PIN, SCL_PIN);

    // 初始化传感器
    initSensors();

    // 初始化显示
    initDisplay();

    // 初始化 WiFi
    initWiFi();

    Serial.println("[INFO] System initialized");
    digitalWrite(LED_PIN, HIGH);
}

void loop() {
    if (millis() - lastUpdate >= UPDATE_INTERVAL) {
        lastUpdate = millis();

        // 读取传感器数据
        float temp = readTemperature();
        float humidity = readHumidity();
        float light = readLight();

        // 输出数据
        logData(temp, humidity, light);

        // 更新显示
        updateDisplay(temp, humidity, light);

        // 上传数据
        if (wifiConnected) {
            uploadData(temp, humidity, light);
        }
    }

    // 处理串口命令
    handleSerialCommand();

    delay(10);
}

void initSensors() {
    // 初始化 DHT22
    dht.begin();
    Serial.println("[INFO] DHT sensor initialized");

    // 初始化 BH1750
    if (lightSensor.begin()) {
        Serial.println("[INFO] BH1750 sensor initialized");
    } else {
        Serial.println("[ERROR] BH1750 sensor init failed");
    }
}

void initDisplay() {
    if (display.begin(SSD1306_SWITCHCAPVCC, 0x3C)) {
        display.clearDisplay();
        display.setTextSize(1);
        display.setTextColor(SSD1306_WHITE);
        display.setCursor(0, 0);
        display.println("ESP32 Env Monitor");
        display.println("Initializing...");
        display.display();
        Serial.println("[INFO] OLED display initialized");
    } else {
        Serial.println("[ERROR] OLED display init failed");
    }
}

void initWiFi() {
    Serial.println("[INFO] WiFi connecting...");
    WiFi.begin(WIFI_SSID, WIFI_PASS);

    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(500);
        Serial.print(".");
        attempts++;
    }

    if (WiFi.status() == WL_CONNECTED) {
        wifiConnected = true;
        Serial.println("\n[INFO] WiFi connected");
        Serial.print("[INFO] IP: ");
        Serial.println(WiFi.localIP());
    } else {
        wifiConnected = false;
        Serial.println("\n[WARN] WiFi connection failed");
    }
}

float readTemperature() {
    float temp = dht.readTemperature();
    if (isnan(temp)) {
        Serial.println("[ERROR] Failed to read temperature");
        return -999.0;
    }
    return temp;
}

float readHumidity() {
    float hum = dht.readHumidity();
    if (isnan(hum)) {
        Serial.println("[ERROR] Failed to read humidity");
        return -999.0;
    }
    return hum;
}

float readLight() {
    float lux = lightSensor.readLightLevel();
    if (lux < 0) {
        Serial.println("[ERROR] Failed to read light level");
        return -999.0;
    }
    return lux;
}

void logData(float temp, float humidity, float light) {
    Serial.printf("[DATA] Temp: %.1f°C, Hum: %.1f%%, Light: %.1flux\n",
                  temp, humidity, light);
}

void updateDisplay(float temp, float humidity, float light) {
    display.clearDisplay();
    display.setTextSize(1);
    display.setTextColor(SSD1306_WHITE);
    display.setCursor(0, 0);

    display.println("=== Env Monitor ===");
    display.println();
    display.printf("Temp:    %.1f C\n", temp);
    display.printf("Humid:   %.1f %%\n", humidity);
    display.printf("Light:   %.1f lux\n", light);
    display.println();
    display.printf("WiFi: %s\n", wifiConnected ? "Connected" : "Disconnected");

    display.display();
}

void uploadData(float temp, float humidity, float light) {
    // TODO: 实现数据上传到云端
    Serial.println("[INFO] Data uploaded successfully");
}

void handleSerialCommand() {
    if (Serial.available()) {
        String cmd = Serial.readStringUntil('\n');
        cmd.trim();

        if (cmd == "status") {
            Serial.println("[INFO] System running");
            Serial.printf("[INFO] Free heap: %d bytes\n", ESP.getFreeHeap());
        } else if (cmd == "restart") {
            Serial.println("[INFO] Restarting...");
            ESP.restart();
        } else if (cmd == "wifi") {
            Serial.printf("[INFO] WiFi status: %s\n",
                         wifiConnected ? "Connected" : "Disconnected");
            if (wifiConnected) {
                Serial.printf("[INFO] IP: %s\n", WiFi.localIP().toString().c_str());
            }
        }
    }
}
