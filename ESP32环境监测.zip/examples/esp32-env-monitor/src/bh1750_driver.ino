// ============================================
// BH1750 光照传感器驱动
// 生成时间: 2026-05-06 10:00:08
// ============================================

#include <BH1750.h>
#include <Wire.h>

// 配置定义
#define BH1750_I2C_ADDR 0x23
#define BH1750_RETRY_COUNT 3
#define BH1750_RETRY_DELAY 500

// 全局对象
BH1750 lightSensor;

// 状态变量
bool bh1750Initialized = false;
float lastLightLevel = -1.0;

/**
 * 初始化 BH1750 传感器
 * @return true 成功, false 失败
 */
bool bh1750_init() {
    if (lightSensor.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
        Serial.println("[INFO] BH1750 sensor initialized");
        bh1750Initialized = true;
        return true;
    } else {
        Serial.println("[ERROR] BH1750 sensor init failed");
        bh1750Initialized = false;
        return false;
    }
}

/**
 * 读取光照强度
 * @return 光照值 (lux)，失败返回 -1
 */
float bh1750_read_light() {
    if (!bh1750Initialized) {
        Serial.println("[ERROR] BH1750 not initialized");
        return -1.0;
    }

    int retryCount = 0;
    float lux = -1.0;

    while (retryCount < BH1750_RETRY_COUNT) {
        lux = lightSensor.readLightLevel();

        if (lux >= 0) {
            lastLightLevel = lux;
            return lux;
        }

        retryCount++;
        if (retryCount < BH1750_RETRY_COUNT) {
            Serial.printf("[WARN] BH1750 read failed, retry %d/%d\n",
                         retryCount, BH1750_RETRY_COUNT);
            delay(BH1750_RETRY_DELAY);
        }
    }

    Serial.println("[ERROR] Failed to read light level");
    return lastLightLevel;  // 返回上次有效值
}

/**
 * 检查 BH1750 传感器状态
 * @return true 正常, false 异常
 */
bool bh1750_is_ready() {
    return bh1750Initialized;
}

/**
 * 设置测量模式
 * @param mode 测量模式
 * @return true 成功, false 失败
 */
bool bh1750_set_mode(BH1750::Mode mode) {
    if (!bh1750Initialized) {
        return false;
    }

    if (lightSensor.begin(mode)) {
        Serial.printf("[INFO] BH1750 mode set to %d\n", mode);
        return true;
    } else {
        Serial.println("[ERROR] Failed to set BH1750 mode");
        return false;
    }
}

/**
 * 获取传感器信息
 */
void bh1750_print_info() {
    Serial.println("[INFO] BH1750 Sensor Info:");
    Serial.printf("  I2C Address: 0x%02X\n", BH1750_I2C_ADDR);
    Serial.printf("  Initialized: %s\n", bh1750Initialized ? "Yes" : "No");
    Serial.printf("  Last Light: %.1f lux\n", lastLightLevel);
}

/**
 * 扫描 I2C 总线
 */
void i2c_scan() {
    Serial.println("[INFO] Scanning I2C bus...");

    byte count = 0;
    for (byte addr = 1; addr < 127; addr++) {
        Wire.beginTransmission(addr);
        if (Wire.endTransmission() == 0) {
            Serial.printf("[INFO] I2C device found at 0x%02X\n", addr);
            count++;
        }
    }

    if (count == 0) {
        Serial.println("[WARN] No I2C devices found");
    } else {
        Serial.printf("[INFO] Found %d I2C device(s)\n", count);
    }
}
