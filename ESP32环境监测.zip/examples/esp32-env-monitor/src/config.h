// ============================================
// ESP32 智能环境监测系统 - 配置文件
// 生成时间: 2026-05-06 10:00:08
// ============================================

#ifndef CONFIG_H
#define CONFIG_H

// WiFi 配置
#define WIFI_SSID "your_ssid"
#define WIFI_PASS "your_password"

// 串口配置
#define SERIAL_BAUD 115200

// 更新间隔 (ms)
#define UPDATE_INTERVAL 5000

// 引脚定义
#define DHT_PIN 4
#define SDA_PIN 21
#define SCL_PIN 22
#define LED_PIN 2

// OLED 配置
#define SCREEN_WIDTH 128
#define SCREEN_HEIGHT 64
#define OLED_RESET -1
#define OLED_ADDRESS 0x3C

// I2C 地址
#define BH1750_ADDRESS 0x23
#define SSD1306_ADDRESS 0x3C

// 调试配置
#define DEBUG_ENABLED 1
#define LOG_LEVEL LOG_INFO

// WiFi 配置
#define WIFI_TIMEOUT 20000
#define WIFI_RETRY_COUNT 3

// 数据上传配置
#define UPLOAD_INTERVAL 30000
#define SERVER_URL "http://your-server.com/api/data"

#endif // CONFIG_H
