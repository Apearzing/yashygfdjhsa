// ============================================
// DHT22 温湿度传感器驱动
// 生成时间: 2026-05-06 10:00:08
// ============================================

#include <DHT.h>

// 配置定义
#define DHT_PIN 4
#define DHT_TYPE DHT22
#define DHT_RETRY_COUNT 3
#define DHT_RETRY_DELAY 1000

// 全局对象
DHT dht(DHT_PIN, DHT_TYPE);

// 状态变量
bool dhtInitialized = false;
float lastTemperature = NAN;
float lastHumidity = NAN;

/**
 * 初始化 DHT 传感器
 * @return true 成功, false 失败
 */
bool dht_init() {
    dht.begin();

    // 等待传感器稳定
    delay(2000);

    // 测试读取
    float temp = dht.readTemperature();
    float hum = dht.readHumidity();

    if (isnan(temp) || isnan(hum)) {
        Serial.println("[ERROR] DHT sensor init failed");
        dhtInitialized = false;
        return false;
    }

    Serial.println("[INFO] DHT sensor initialized");
    dhtInitialized = true;
    return true;
}

/**
 * 读取温度
 * @return 温度值 (°C)，失败返回 NAN
 */
float dht_read_temperature() {
    int retryCount = 0;
    float temp = NAN;

    while (retryCount < DHT_RETRY_COUNT) {
        temp = dht.readTemperature();

        if (!isnan(temp)) {
            lastTemperature = temp;
            return temp;
        }

        retryCount++;
        if (retryCount < DHT_RETRY_COUNT) {
            Serial.printf("[WARN] DHT read failed, retry %d/%d\n",
                         retryCount, DHT_RETRY_COUNT);
            delay(DHT_RETRY_DELAY);
        }
    }

    Serial.println("[ERROR] Failed to read temperature");
    return lastTemperature;  // 返回上次有效值
}

/**
 * 读取湿度
 * @return 湿度值 (%)，失败返回 NAN
 */
float dht_read_humidity() {
    int retryCount = 0;
    float hum = NAN;

    while (retryCount < DHT_RETRY_COUNT) {
        hum = dht.readHumidity();

        if (!isnan(hum)) {
            lastHumidity = hum;
            return hum;
        }

        retryCount++;
        if (retryCount < DHT_RETRY_COUNT) {
            Serial.printf("[WARN] DHT read failed, retry %d/%d\n",
                         retryCount, DHT_RETRY_COUNT);
            delay(DHT_RETRY_DELAY);
        }
    }

    Serial.println("[ERROR] Failed to read humidity");
    return lastHumidity;  // 返回上次有效值
}

/**
 * 同时读取温湿度
 * @param temp 温度指针
 * @param hum 湿度指针
 * @return true 成功, false 失败
 */
bool dht_read(float *temp, float *hum) {
    *temp = dht_read_temperature();
    *hum = dht_read_humidity();

    if (isnan(*temp) || isnan(*hum)) {
        return false;
    }

    return true;
}

/**
 * 检查 DHT 传感器状态
 * @return true 正常, false 异常
 */
bool dht_is_ready() {
    return dhtInitialized;
}

/**
 * 获取传感器信息
 */
void dht_print_info() {
    Serial.println("[INFO] DHT Sensor Info:");
    Serial.printf("  Pin: %d\n", DHT_PIN);
    Serial.printf("  Type: %s\n", DHT_TYPE == DHT22 ? "DHT22" : "DHT11");
    Serial.printf("  Initialized: %s\n", dhtInitialized ? "Yes" : "No");
    Serial.printf("  Last Temp: %.1f°C\n", lastTemperature);
    Serial.printf("  Last Hum: %.1f%%\n", lastHumidity);
}
