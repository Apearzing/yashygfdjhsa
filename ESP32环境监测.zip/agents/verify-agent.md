# 验证与文档 Agent (Verify Agent)

## 角色定义

验证与文档 Agent 负责自动生成单元测试用例，驱动模拟器完成功能验证，同时根据代码与测试结果生成规范的项目文档。

## 核心能力

1. **测试生成**: 自动生成单元测试用例
2. **模拟验证**: 驱动模拟器完成功能验证
3. **覆盖率分析**: 分析代码覆盖率
4. **文档生成**: 生成项目说明文档
5. **接线图生成**: 自动生成硬件接线图
6. **演示指南**: 生成演示流程文档

## 工作流程

```mermaid
graph TD
    A[接收代码] --> B[代码分析]
    B --> C[生成测试用例]
    C --> D[运行测试]
    D --> E{测试通过?}
    E -->|否| F[生成修复建议]
    F --> G[返回开发Agent]
    E -->|是| H[覆盖率分析]
    H --> I{覆盖率达标?}
    I -->|否| J[补充测试用例]
    J --> D
    I -->|是| K[生成文档]
    K --> L[生成接线图]
    L --> M[生成演示指南]
    M --> N[输出完整项目]
```

## 测试用例生成

### 单元测试模板 (Unity 框架)

```c
#include "unity.h"
#include "sensor_driver.h"

// 测试固件
void setUp(void) {
    sensor_init();
}

void tearDown(void) {
    sensor_deinit();
}

// 测试用例
void test_sensor_init_success(void) {
    TEST_ASSERT_EQUAL(0, sensor_init());
}

void test_sensor_read_valid_range(void) {
    float value = sensor_read_temperature();
    TEST_ASSERT_FLOAT_WITHIN(0.1, 25.0, value);
}

void test_sensor_read_timeout(void) {
    // 模拟超时场景
    simulate_timeout();
    float value = sensor_read_temperature();
    TEST_ASSERT_FLOAT_IS NAN(value);
}

// 测试运行器
int main(void) {
    UNITY_BEGIN();
    RUN_TEST(test_sensor_init_success);
    RUN_TEST(test_sensor_read_valid_range);
    RUN_TEST(test_sensor_read_timeout);
    return UNITY_END();
}
```

### Python 测试模板 (pytest)

```python
import pytest
from sensor_driver import SensorDriver

@pytest.fixture
def sensor():
    """传感器驱动固件"""
    driver = SensorDriver(port="/dev/ttyUSB0")
    yield driver
    driver.close()

def test_sensor_init(sensor):
    """测试传感器初始化"""
    assert sensor.is_connected()

def test_read_temperature(sensor):
    """测试温度读取"""
    temp = sensor.read_temperature()
    assert -40 <= temp <= 85

def test_read_humidity(sensor):
    """测试湿度读取"""
    humidity = sensor.read_humidity()
    assert 0 <= humidity <= 100

def test_sensor_timeout(sensor, monkeypatch):
    """测试超时处理"""
    monkeypatch.setattr(sensor, "_send_command", lambda x: None)
    with pytest.raises(TimeoutError):
        sensor.read_temperature()
```

## 代码覆盖率报告

```
========================== Coverage Report ==========================
File                    Stmts   Miss  Cover   Missing
------------------------------------------------------
src/sensor_driver.c       120     15    88%   45-52, 78-85
src/wifi_manager.c         85     10    88%   32-38, 95-100
src/data_processor.c       95      5    95%   112-115
------------------------------------------------------
TOTAL                     300     30    90%
=====================================================================
```

## 文档生成模板

### 项目说明文档

```markdown
# 项目名称

## 1. 项目概述
- 开发目的
- 主要功能
- 技术选型

## 2. 系统架构
- 硬件架构图
- 软件架构图
- 数据流图

## 3. 硬件设计
- 元器件清单
- 接线图
- PCB 设计（如有）

## 4. 软件设计
- 模块划分
- 关键算法
- 时序图

## 5. 使用说明
- 环境准备
- 编译烧录
- 运行演示

## 6. 测试报告
- 测试用例
- 测试结果
- 覆盖率

## 7. 常见问题
- FAQ
- 故障排除
```

### 接线图模板 (Mermaid)

```mermaid
graph LR
    subgraph ESP32
        D21[GPIO21 - SDA]
        D22[GPIO22 - SCL]
        D2[GPIO2]
        D4[GPIO4]
        GND[GND]
        VIN[3.3V]
    end

    subgraph DHT22
        DHT_VCC[VCC]
        DHT_DATA[DATA]
        DHT_GND[GND]
    end

    subgraph BH1750
        BH_VCC[VCC]
        BH_SDA[SDA]
        BH_SCL[SCL]
        BH_GND[GND]
    end

    VIN --> DHT_VCC
    VIN --> BH_VCC
    D21 --> BH_SDA
    D22 --> BH_SCL
    D4 --> DHT_DATA
    GND --> DHT_GND
    GND --> BH_GND
```

## 演示流程模板

```markdown
# 演示流程

## 准备工作
1. 检查硬件连接
2. 确认串口设备
3. 启动监控软件

## 演示步骤

### Step 1: 系统启动
- 上电，观察 LED 状态
- 等待 WiFi 连接成功
- 串口输出 "System initialized"

### Step 2: 数据采集
- 观察传感器数据输出
- 验证数据合理性
- 检查数据上传状态

### Step 3: 异常处理
- 模拟传感器断开
- 观察错误处理
- 恢复连接后自动重连

## 预期结果
- 所有传感器正常读数
- 数据成功上传云端
- 异常情况正确处理
```

## Prompt 模板

```markdown
你是一个嵌入式系统测试专家。请根据以下代码生成完整的测试方案。

## 代码文件
{code_files}

## 测试要求
1. 单元测试覆盖率 > 80%
2. 包含正常流程和异常流程
3. 包含边界条件测试
4. 生成测试报告模板
5. 生成接线图和演示指南

请生成完整的测试代码和文档。
```
