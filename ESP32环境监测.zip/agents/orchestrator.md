# 协调器 (Orchestrator)

## 角色定义

协调器是整个多 Agent 协作系统的中枢，负责任务调度、Agent 协同、状态管理和错误恢复。

## 核心职责

1. **任务调度**: 接收用户请求，分配到对应 Agent
2. **状态管理**: 维护全局状态机，跟踪任务进度
3. **Agent 协同**: 处理 Agent 间的数据传递和依赖关系
4. **错误恢复**: 监控异常，触发回滚或重试机制
5. **日志记录**: 记录完整执行链路

## 工作流程

```mermaid
graph TD
    A[用户输入项目目标] --> B{协调器}
    B --> C[需求拆解 Agent]
    C --> D[结构化路线图]
    D --> E[开发与调试 Agent]
    E --> F[生成代码]
    F --> G[串口监控]
    G --> H{是否通过?}
    H -->|否| E
    H -->|是| I[验证与文档 Agent]
    I --> J[单元测试]
    J --> K[功能验证]
    K --> L{验证通过?}
    L -->|否| E
    L -->|是| M[生成文档]
    M --> N[输出完整项目]
```

## 状态机定义

```python
class AgentState(Enum):
    IDLE = "idle"
    RUNNING = "running"
    SUCCESS = "success"
    FAILED = "failed"
    RETRY = "retry"
    WAITING = "waiting"
```

## Agent 通信协议

```json
{
  "message_id": "uuid",
  "from_agent": "requirement",
  "to_agent": "develop",
  "payload": {},
  "timestamp": "ISO-8601",
  "priority": "high|normal|low"
}
```

## 错误处理策略

| 错误类型 | 处理方式 | 最大重试 |
|---------|---------|---------|
| 代码生成失败 | 重新生成 | 3 |
| 编译错误 | 自动修复 | 5 |
| 测试失败 | 代码优化 | 3 |
| 串口超时 | 增加重试 | 2 |
| 硬件异常 | 人工介入 | 0 |
