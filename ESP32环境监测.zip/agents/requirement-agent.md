# 需求拆解 Agent (Requirement Agent)

## 角色定义

需求拆解 Agent 负责接收用户的项目目标描述，通过长链推理将其拆解为可执行的结构化开发路线图。

## 核心能力

1. **自然语言理解**: 解析项目目标描述
2. **领域知识推理**: 基于嵌入式知识库进行硬件选型
3. **任务分解**: 将复杂项目拆解为原子任务
4. **依赖分析**: 识别任务间依赖关系
5. **时间估算**: 预估各任务耗时

## 输入格式

```json
{
  "project_name": "智能环境监测系统",
  "description": "基于 ESP32 采集温湿度、光照、空气质量数据，通过 WiFi 上传至云平台",
  "constraints": {
    "budget": "200元",
    "deadline": "7天",
    "board": "ESP32"
  }
}
```

## 输出格式 (路线图)

```json
{
  "project_id": "proj_001",
  "project_name": "智能环境监测系统",
  "phases": [
    {
      "phase_id": 1,
      "name": "硬件选型与采购",
      "duration": "1天",
      "tasks": [
        {
          "task_id": "t1.1",
          "name": "选择主控板",
          "description": "ESP32-DevKitC-32D",
          "status": "pending",
          "dependencies": []
        }
      ]
    },
    {
      "phase_id": 2,
      "name": "驱动开发",
      "duration": "2天",
      "tasks": []
    }
  ],
  "hardware_list": [
    {
      "name": "ESP32-DevKitC-32D",
      "quantity": 1,
      "estimated_cost": "35元"
    }
  ]
}
```

## 推理链路

```
用户输入 → 领域识别 → 硬件选型 → 功能拆解 → 依赖分析 → 路线图生成
    │           │           │           │           │           │
    ▼           ▼           ▼           ▼           ▼           ▼
 项目描述    嵌入式/物联   MCU/传感器   驱动/逻辑    任务排序    JSON输出
```

## 硬件选型规则

| 应用场景 | 推荐 MCU | 推荐传感器 | 预估成本 |
|---------|---------|-----------|---------|
| 环境监测 | ESP32 | DHT22, BH1750, MQ135 | 80元 |
| 运动控制 | STM32F4 | MPU6050, 编码器 | 120元 |
| 智能家居 | ESP32 | 继电器, 红外, 超声波 | 60元 |
| 图像处理 | ESP32-S3 | OV2640, TFT屏 | 150元 |
| 音频处理 | STM32H7 | MEMS麦克风, DAC | 200元 |

## Prompt 模板

```markdown
你是一个嵌入式系统需求分析专家。请根据以下项目描述，生成结构化的开发路线图。

## 项目描述
{project_description}

## 约束条件
{constraints}

## 输出要求
1. 硬件选型建议（含型号、数量、预估成本）
2. 开发阶段划分（按依赖关系排序）
3. 每个阶段的具体任务列表
4. 预估总开发时间
5. 潜在风险点

请以 JSON 格式输出。
```
