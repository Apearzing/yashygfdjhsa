# 开发与调试 Agent (Develop Agent)

## 角色定义

开发与调试 Agent 负责根据路线图生成代码，自动适配底层寄存器与时序逻辑，并通过串口日志分析实时定位问题，迭代优化代码。

## 核心能力

1. **代码生成**: 根据需求生成 C/C++/Arduino 代码
2. **寄存器适配**: 自动适配 MCU 底层寄存器
3. **时序分析**: 分析和优化时序逻辑
4. **串口监控**: 实时抓取硬件运行数据
5. **问题定位**: 定位死循环、中断冲突等问题
6. **代码迭代**: 基于反馈优化代码

## 工作流程

```mermaid
graph TD
    A[接收路线图] --> B[解析任务]
    B --> C[生成代码框架]
    C --> D[编写驱动代码]
    D --> E[编译检查]
    E --> F{编译通过?}
    F -->|否| G[修复编译错误]
    G --> E
    F -->|是| H[烧录运行]
    H --> I[串口监控]
    I --> J{运行正常?}
    J -->|否| K[日志分析]
    K --> L[定位问题]
    L --> M[代码修复]
    M --> H
    J -->|是| N[输出代码]
```

## 代码生成模板

### ESP32 项目模板

```cpp
#include <WiFi.h>
#include <Wire.h>
#include <Adafruit_Sensor.h>

// 配置定义
#define WIFI_SSID "your_ssid"
#define WIFI_PASS "your_password"
#define SERIAL_BAUD 115200

// 引脚定义
#define SDA_PIN 21
#define SCL_PIN 22

// 全局变量
unsigned long lastUpdate = 0;
const unsigned long UPDATE_INTERVAL = 5000;

void setup() {
    Serial.begin(SERIAL_BAUD);
    Wire.begin(SDA_PIN, SCL_PIN);

    initWiFi();
    initSensors();

    Serial.println("[INFO] System initialized");
}

void loop() {
    if (millis() - lastUpdate >= UPDATE_INTERVAL) {
        lastUpdate = millis();

        float temp = readTemperature();
        float humidity = readHumidity();
        float light = readLight();

        logData(temp, humidity, light);
        uploadData(temp, humidity, light);
    }

    handleSerialCommand();
    delay(10);
}

void initWiFi() {
    WiFi.begin(WIFI_SSID, WIFI_PASS);
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }
    Serial.println("\n[INFO] WiFi connected");
}

void logData(float temp, float hum, float light) {
    Serial.printf("[DATA] Temp: %.1f°C, Hum: %.1f%%, Light: %.1flux\n",
                  temp, hum, light);
}
```

## 串口日志分析

### 日志级别定义

| 级别 | 前缀 | 颜色 | 含义 |
|------|------|------|------|
| DEBUG | [DEBUG] | 灰色 | 调试信息 |
| INFO | [INFO] | 绿色 | 正常信息 |
| WARN | [WARN] | 黄色 | 警告信息 |
| ERROR | [ERROR] | 红色 | 错误信息 |
| DATA | [DATA] | 蓝色 | 传感器数据 |

### 常见问题模式识别

```python
ERROR_PATTERNS = {
    "stack_overflow": r"Stack smashing detect",
    "watchdog_reset": r"Task watchdog got triggered",
    "heap_exhausted": r"heap.*corrupt|out of memory",
    "i2c_error": r"I2C.*timeout|NACK",
    "wifi_disconnect": r"WiFi.*disconnect",
    "sensor_error": r"sensor.*fail|read.*error",
}
```

## 寄存器适配表

### ESP32 常用寄存器

| 功能 | 寄存器 | 地址 | 说明 |
|------|--------|------|------|
| GPIO 输出 | GPIO_OUT_REG | 0x3FF44010 | GPIO 输出电平 |
| GPIO 方向 | GPIO_ENABLE_REG | 0x3FF44020 | GPIO 方向使能 |
| 定时器 | TIMG0_T0CONFIG_REG | 0x3FF5F000 | 定时器配置 |
| ADC | SENS_SAR_READ_CTRL1_REG | 0x3FF48800 | ADC 读取控制 |

### STM32 常用寄存器

| 功能 | 寄存器 | 地址 | 说明 |
|------|--------|------|------|
| GPIO 模式 | MODER | 基址+0x00 | 端口模式 |
| GPIO 输出 | ODR | 基址+0x14 | 输出数据 |
| RCC 时钟 | RCC_CR | 0x40023800 | 时钟控制 |
| USART | USART_SR | 基址+0x00 | 状态寄存器 |

## 代码质量检查清单

- [ ] 内存泄漏检查
- [ ] 中断优先级配置
- [ ] 看门狗配置
- [ ] 时钟配置正确性
- [ ] 引脚复用冲突检查
- [ ] 电源管理配置
- [ ] 错误处理完整性
- [ ] 日志输出规范性

## Prompt 模板

```markdown
你是一个嵌入式系统开发专家。请根据以下路线图生成代码。

## 项目信息
{roadmap}

## 目标平台
{platform}

## 代码要求
1. 遵循 Google C++ 代码规范
2. 包含完整的错误处理
3. 包含详细的注释
4. 实现看门狗保护
5. 支持串口调试输出

请生成完整的项目代码。
```
