# 截图和录屏

本目录包含项目的截图和录屏文件。

## 文件列表

### 终端运行日志

- `terminal-demo.log` - 终端运行日志示例

### Agent 工作流截图

- `workflow-overview.png` - 工作流概览
- `requirement-agent.png` - 需求拆解 Agent 运行
- `develop-agent.png` - 开发调试 Agent 运行
- `verify-agent.png` - 验证文档 Agent 运行

### 演示录屏

- `demo-full.mp4` - 完整演示录屏
- `demo-requirement.mp4` - 需求分析演示
- `demo-codegen.mp4` - 代码生成演示
- `demo-monitor.mp4` - 串口监控演示

## 使用说明

1. 截图使用 PNG 格式，分辨率至少 1920x1080
2. 录屏使用 MP4 格式，帧率 30fps
3. 文件命名使用小写字母和连字符
4. 添加简要说明文档

## 截图规范

### 终端截图

- 使用深色主题
- 字体大小 14-16px
- 包含完整的命令和输出
- 高亮关键信息

### 工作流截图

- 展示完整的 Agent 协作流程
- 标注关键节点
- 使用清晰的箭头和连线

### 演示录屏

- 屏幕分辨率 1920x1080
- 录制完整操作流程
- 添加字幕说明
- 时长控制在 5 分钟以内
