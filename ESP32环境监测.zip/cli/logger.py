"""
日志模块 - 统一日志管理
"""

import logging
import os
import sys
from datetime import datetime
from typing import Optional

from rich.console import Console
from rich.logging import RichHandler


def setup_logger(
    name: str = "embedded-agent",
    level: str = "INFO",
    log_file: Optional[str] = None,
    rich_console: bool = True,
) -> logging.Logger:
    """
    设置日志器

    Args:
        name: 日志器名称
        level: 日志级别
        log_file: 日志文件路径
        rich_console: 是否使用 Rich 控制台

    Returns:
        配置好的日志器
    """
    # 创建日志器
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, level.upper(), logging.INFO))

    # 清除现有处理器
    logger.handlers.clear()

    # 控制台处理器
    if rich_console:
        console_handler = RichHandler(
            console=Console(stderr=True),
            show_time=True,
            show_level=True,
            show_path=False,
            markup=True,
        )
    else:
        console_handler = logging.StreamHandler(sys.stdout)

    console_handler.setLevel(logging.DEBUG)
    console_format = logging.Formatter("%(message)s")
    console_handler.setFormatter(console_format)
    logger.addHandler(console_handler)

    # 文件处理器
    if log_file:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_format = logging.Formatter(
            "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
        )
        file_handler.setFormatter(file_format)
        logger.addHandler(file_handler)

    return logger


class AgentLogger:
    """Agent 专用日志器"""

    def __init__(self, agent_name: str, log_dir: str = "logs"):
        """
        初始化 Agent 日志器

        Args:
            agent_name: Agent 名称
            log_dir: 日志目录
        """
        self.agent_name = agent_name
        self.log_dir = log_dir

        # 创建日志文件
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_file = os.path.join(log_dir, f"{agent_name}_{timestamp}.log")

        # 设置日志器
        self.logger = setup_logger(
            name=agent_name,
            log_file=log_file,
            rich_console=True,
        )

        # 统计信息
        self.stats = {
            "start_time": datetime.now(),
            "total_messages": 0,
            "errors": 0,
            "warnings": 0,
        }

    def info(self, message: str):
        """记录信息"""
        self.logger.info(message)
        self.stats["total_messages"] += 1

    def debug(self, message: str):
        """记录调试信息"""
        self.logger.debug(message)
        self.stats["total_messages"] += 1

    def warning(self, message: str):
        """记录警告"""
        self.logger.warning(message)
        self.stats["warnings"] += 1
        self.stats["total_messages"] += 1

    def error(self, message: str):
        """记录错误"""
        self.logger.error(message)
        self.stats["errors"] += 1
        self.stats["total_messages"] += 1

    def success(self, message: str):
        """记录成功"""
        self.logger.info(f"[green]✓ {message}[/green]")
        self.stats["total_messages"] += 1

    def get_stats(self) -> dict:
        """获取统计信息"""
        duration = datetime.now() - self.stats["start_time"]
        return {
            "agent": self.agent_name,
            "duration": str(duration),
            "total_messages": self.stats["total_messages"],
            "errors": self.stats["errors"],
            "warnings": self.stats["warnings"],
        }
