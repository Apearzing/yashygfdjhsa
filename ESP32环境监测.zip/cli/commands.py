"""
CLI 命令定义 - 提供命令行接口
"""

import json
import os
import sys
from datetime import datetime
from typing import Optional

import click
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.tree import Tree

console = Console()


@click.group()
@click.version_option(version="1.0.0", prog_name="embedded-agent")
def cli():
    """
    嵌入式竞赛全链路智能开发与验证 Agent 系统

    基于多 Agent 协作的嵌入式竞赛项目自动化开发平台
    """
    pass


@cli.command()
@click.option("--project", "-p", required=True, help="项目名称")
@click.option("--board", "-b", default="esp32", help="目标开发板 (esp32/stm32/arduino)")
@click.option("--budget", default=200, help="预算上限 (元)")
def init(project: str, board: str, budget: int):
    """初始化新项目"""
    from engines.requirement_engine import RequirementEngine

    console.print(Panel(f"[bold blue]初始化项目: {project}[/bold blue]"))

    # 显示进度
    with console.status("[bold green]正在分析需求..."):
        engine = RequirementEngine()
        roadmap = engine.parse_requirement(
            project_name=project,
            description=project,
            constraints={"budget": budget, "board": board},
        )

    # 保存路线图
    os.makedirs("output", exist_ok=True)
    with open("output/roadmap.json", "w", encoding="utf-8") as f:
        json.dump(roadmap, f, indent=2, ensure_ascii=False)

    # 显示结果
    console.print("\n[bold green]✓ 项目初始化完成[/bold green]")

    # 显示硬件清单
    console.print("\n[bold]硬件清单:[/bold]")
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("类别", style="cyan")
    table.add_column("名称", style="green")
    table.add_column("数量", justify="right")
    table.add_column("单价", justify="right")

    for item in roadmap.get("hardware_list", []):
        table.add_row(
            item.get("category", ""),
            item.get("name", ""),
            str(item.get("quantity", 1)),
            f"¥{item.get('price', 0)}",
        )

    console.print(table)
    console.print(f"\n[bold]预估成本:[/bold] ¥{roadmap.get('total_cost', 0)}")
    console.print(f"[bold]预估工期:[/bold] {roadmap.get('estimated_days', 0)} 天")

    # 显示开发计划
    console.print("\n[bold]开发计划:[/bold]")
    tree = Tree("📋 开发阶段")
    for phase in roadmap.get("phases", []):
        phase_node = tree.add(f"[cyan]{phase['name']}[/cyan] ({phase['duration']})")
        for task in phase.get("tasks", []):
            phase_node.add(f"[green]✓[/green] {task['name']}")

    console.print(tree)
    console.print(f"\n[dim]路线图已保存到: output/roadmap.json[/dim]")


@cli.command()
@click.option("--project", "-p", required=True, help="项目名称")
@click.option("--board", "-b", default="esp32", help="目标开发板")
@click.option("--output", "-o", default="src", help="输出目录")
def generate(project: str, board: str, output: str):
    """生成项目代码"""
    from engines.code_gen_engine import CodeGenEngine
    from engines.requirement_engine import RequirementEngine

    console.print(Panel(f"[bold blue]生成项目代码: {project}[/bold blue]"))

    # 加载或生成路线图
    roadmap_path = "output/roadmap.json"
    if os.path.exists(roadmap_path):
        with open(roadmap_path, "r", encoding="utf-8") as f:
            roadmap = json.load(f)
    else:
        console.print("[yellow]未找到路线图，正在生成...[/yellow]")
        engine = RequirementEngine()
        roadmap = engine.parse_requirement(
            project_name=project,
            description=project,
            constraints={"board": board},
        )

    # 生成代码
    with console.status("[bold green]正在生成代码..."):
        code_engine = CodeGenEngine()
        files = code_engine.generate_project(roadmap, output_dir=output)

    # 显示结果
    console.print("\n[bold green]✓ 代码生成完成[/bold green]")
    console.print(f"\n[bold]生成的文件:[/bold]")
    for filepath in files.keys():
        console.print(f"  [green]✓[/green] {filepath}")

    console.print(f"\n[dim]代码已保存到: {output}/[/dim]")


@cli.command()
@click.option("--port", "-p", default=None, help="串口号")
@click.option("--baud", "-b", default=115200, help="波特率")
@click.option("--duration", "-d", default=0, help="监控时长 (秒, 0=持续)")
def monitor(port: Optional[str], baud: int, duration: int):
    """启动串口监控"""
    from engines.serial_monitor import SerialMonitor

    # 列出可用串口
    if port is None:
        ports = SerialMonitor.list_ports()
        if not ports:
            console.print("[red]未找到可用串口[/red]")
            return

        console.print("[bold]可用串口:[/bold]")
        for p in ports:
            console.print(f"  {p['device']}: {p['description']}")

        port = ports[0]["device"]
        console.print(f"\n使用串口: {port}")

    # 启动监控
    console.print(Panel(f"[bold blue]串口监控: {port} @ {baud} baud[/bold blue]"))

    monitor = SerialMonitor(port=port, baudrate=baud)

    def log_callback(log_entry):
        """日志回调"""
        level = log_entry["level"]
        message = log_entry["message"]

        colors = {
            "DEBUG": "[dim]",
            "INFO": "[green]",
            "WARN": "[yellow]",
            "ERROR": "[red]",
            "DATA": "[blue]",
        }

        color = colors.get(level, "")
        console.print(f"{color}[{level}] {message}[/]")

    monitor.add_callback(log_callback)

    try:
        monitor.start(background=False)
    except KeyboardInterrupt:
        console.print("\n[yellow]正在停止监控...[/yellow]")
        monitor.stop()

        # 显示统计
        stats = monitor.get_statistics()
        console.print("\n[bold]监控统计:[/bold]")
        console.print(f"  总日志数: {stats['total_logs']}")
        console.print(f"  错误数: {stats['total_errors']}")
        console.print(f"  数据点数: {stats['total_data_points']}")


@cli.command()
@click.option("--code-dir", "-c", default="src", help="代码目录")
@click.option("--output", "-o", default="tests", help="测试输出目录")
@click.option("--framework", "-f", default="unity", help="测试框架 (unity/pytest)")
def test(code_dir: str, output: str, framework: str):
    """生成并运行测试"""
    from engines.test_gen_engine import TestGenEngine

    console.print(Panel("[bold blue]生成测试用例[/bold blue]"))

    # 读取代码文件
    code_files = {}
    if os.path.exists(code_dir):
        for filename in os.listdir(code_dir):
            if filename.endswith((".c", ".ino", ".cpp", ".h")):
                filepath = os.path.join(code_dir, filename)
                with open(filepath, "r", encoding="utf-8") as f:
                    code_files[filename] = f.read()

    if not code_files:
        console.print("[red]未找到代码文件[/red]")
        return

    # 生成测试
    with console.status("[bold green]正在生成测试用例..."):
        engine = TestGenEngine(framework=framework)
        test_files = engine.generate_tests(code_files, output_dir=output)

    # 显示结果
    console.print("\n[bold green]✓ 测试生成完成[/bold green]")
    console.print(f"\n[bold]生成的测试文件:[/bold]")
    for filepath in test_files.keys():
        console.print(f"  [green]✓[/green] {filepath}")

    console.print(f"\n[dim]测试已保存到: {output}/[/dim]")


@cli.command()
@click.option("--roadmap", "-r", default="output/roadmap.json", help="路线图文件")
@click.option("--code-dir", "-c", default="src", help="代码目录")
@click.option("--output", "-o", default="docs", help="文档输出目录")
def docs(roadmap: str, code_dir: str, output: str):
    """生成项目文档"""
    from engines.doc_gen_engine import DocGenEngine

    console.print(Panel("[bold blue]生成项目文档[/bold blue]"))

    # 加载路线图
    if not os.path.exists(roadmap):
        console.print("[red]未找到路线图文件[/red]")
        return

    with open(roadmap, "r", encoding="utf-8") as f:
        roadmap_data = json.load(f)

    # 读取代码文件
    code_files = {}
    if os.path.exists(code_dir):
        for filename in os.listdir(code_dir):
            if filename.endswith((".c", ".ino", ".cpp", ".h")):
                filepath = os.path.join(code_dir, filename)
                with open(filepath, "r", encoding="utf-8") as f:
                    code_files[filename] = f.read()

    # 生成文档
    with console.status("[bold green]正在生成文档..."):
        engine = DocGenEngine()
        docs = engine.generate_docs(roadmap_data, code_files, output_dir=output)

    # 显示结果
    console.print("\n[bold green]✓ 文档生成完成[/bold green]")
    console.print(f"\n[bold]生成的文档:[/bold]")
    for filepath in docs.keys():
        console.print(f"  [green]✓[/green] {filepath}")

    console.print(f"\n[dim]文档已保存到: {output}/[/dim]")


@cli.command()
@click.option("--project", "-p", required=True, help="项目名称")
@click.option("--board", "-b", default="esp32", help="目标开发板")
@click.option("--budget", default=200, help="预算上限")
def run(project: str, board: str, budget: int):
    """运行完整开发流程"""
    from engines.code_gen_engine import CodeGenEngine
    from engines.doc_gen_engine import DocGenEngine
    from engines.requirement_engine import RequirementEngine
    from engines.test_gen_engine import TestGenEngine

    console.print(Panel("[bold blue]运行完整开发流程[/bold blue]"))

    # Step 1: 需求分析
    console.print("\n[bold]Step 1/4: 需求分析[/bold]")
    with console.status("[bold green]正在分析需求..."):
        req_engine = RequirementEngine()
        roadmap = req_engine.parse_requirement(
            project_name=project,
            description=project,
            constraints={"budget": budget, "board": board},
        )

    # 保存路线图
    os.makedirs("output", exist_ok=True)
    with open("output/roadmap.json", "w", encoding="utf-8") as f:
        json.dump(roadmap, f, indent=2, ensure_ascii=False)

    console.print("[green]✓ 需求分析完成[/green]")

    # Step 2: 代码生成
    console.print("\n[bold]Step 2/4: 代码生成[/bold]")
    with console.status("[bold green]正在生成代码..."):
        code_engine = CodeGenEngine()
        code_files = code_engine.generate_project(roadmap, output_dir="src")

    console.print("[green]✓ 代码生成完成[/green]")

    # Step 3: 测试生成
    console.print("\n[bold]Step 3/4: 测试生成[/bold]")
    with console.status("[bold green]正在生成测试..."):
        test_engine = TestGenEngine()
        test_files = test_engine.generate_tests(code_files, output_dir="tests")

    console.print("[green]✓ 测试生成完成[/green]")

    # Step 4: 文档生成
    console.print("\n[bold]Step 4/4: 文档生成[/bold]")
    with console.status("[bold green]正在生成文档..."):
        doc_engine = DocGenEngine()
        docs = doc_engine.generate_docs(roadmap, code_files, output_dir="docs")

    console.print("[green]✓ 文档生成完成[/green]")

    # 显示总结
    console.print("\n" + "=" * 50)
    console.print(Panel("[bold green]项目生成完成！[/bold green]"))

    # 显示文件结构
    console.print("\n[bold]生成的文件结构:[/bold]")
    tree = Tree("📁 项目根目录")
    tree.add("📄 output/roadmap.json")
    src_node = tree.add("📁 src")
    for filename in code_files.keys():
        src_node.add(f"📄 {filename}")
    test_node = tree.add("📁 tests")
    for filename in test_files.keys():
        test_node.add(f"📄 {filename}")
    docs_node = tree.add("📁 docs")
    for filename in docs.keys():
        docs_node.add(f"📄 {filename}")

    console.print(tree)

    # 显示统计
    console.print("\n[bold]项目统计:[/bold]")
    console.print(f"  预估成本: ¥{roadmap.get('total_cost', 0)}")
    console.print(f"  预估工期: {roadmap.get('estimated_days', 0)} 天")
    console.print(f"  代码文件: {len(code_files)} 个")
    console.print(f"  测试文件: {len(test_files)} 个")
    console.print(f"  文档文件: {len(docs)} 个")


@cli.command()
def status():
    """查看系统状态"""
    console.print(Panel("[bold blue]系统状态[/bold blue]"))

    # 检查配置文件
    config_exists = os.path.exists("config.yaml")
    console.print(f"配置文件: [green]✓[/green]" if config_exists else "配置文件: [red]✗[/red]")

    # 检查输出目录
    output_exists = os.path.exists("output")
    console.print(f"输出目录: [green]✓[/green]" if output_exists else "输出目录: [dim]未创建[/dim]")

    # 检查路线图
    roadmap_exists = os.path.exists("output/roadmap.json")
    console.print(f"项目路线图: [green]✓[/green]" if roadmap_exists else "项目路线图: [dim]未生成[/dim]")

    # 检查代码目录
    src_exists = os.path.exists("src")
    console.print(f"代码目录: [green]✓[/green]" if src_exists else "代码目录: [dim]未创建[/dim]")

    # 检查测试目录
    tests_exists = os.path.exists("tests")
    console.print(f"测试目录: [green]✓[/green]" if tests_exists else "测试目录: [dim]未创建[/dim]")

    # 检查文档目录
    docs_exists = os.path.exists("docs")
    console.print(f"文档目录: [green]✓[/green]" if docs_exists else "文档目录: [dim]未创建[/dim]")

    # 显示可用命令
    console.print("\n[bold]可用命令:[/bold]")
    console.print("  embedded-agent init      - 初始化新项目")
    console.print("  embedded-agent generate  - 生成项目代码")
    console.print("  embedded-agent monitor   - 启动串口监控")
    console.print("  embedded-agent test      - 生成测试用例")
    console.print("  embedded-agent docs      - 生成项目文档")
    console.print("  embedded-agent run       - 运行完整流程")
    console.print("  embedded-agent status    - 查看系统状态")


if __name__ == "__main__":
    cli()
