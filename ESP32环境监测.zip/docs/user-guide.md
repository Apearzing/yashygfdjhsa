# 用户指南

## 1. 快速开始

### 1.1 安装依赖

```bash
# 克隆项目
git clone https://github.com/your-username/embedded-agent-sys.git
cd embedded-agent-sys

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
# 或
venv\Scripts\activate  # Windows

# 安装依赖
pip install -r requirements.txt
```

### 1.2 初始化项目

```bash
python cli.py init --project "智能环境监测系统" --board esp32 --budget 200
```

输出示例：
```
╭─────────────────────────────────────────╮
│        初始化项目: 智能环境监测系统        │
╰─────────────────────────────────────────╯

✓ 项目初始化完成

硬件清单:
┌──────────┬──────────┬──────┬──────┐
│ 类别     │ 名称     │ 数量 │ 单价 │
├──────────┼──────────┼──────┼──────┤
│ mcu      │ ESP32    │    1 │ ¥35  │
│ sensor   │ DHT22    │    1 │ ¥12  │
│ sensor   │ BH1750   │    1 │ ¥8   │
│ display  │ SSD1306  │    1 │ ¥15  │
└──────────┴──────────┴──────┴──────┘

预估成本: ¥100
预估工期: 4 天

开发计划:
📋 开发阶段
├── 硬件选型与采购 (1天)
│   ✓ 确认元器件清单
│   ✓ 采购元器件
├── 驱动开发 (2天)
│   ✓ 初始化工程
│   ✓ 编写传感器驱动
│   ✓ 编写通信驱动
├── 功能集成 (2天)
│   ✓ 主程序框架
│   ✓ 数据处理
│   ✓ 显示界面
├── 测试验证 (1天)
│   ✓ 单元测试
│   ✓ 集成测试
│   ✓ 压力测试
└── 文档与演示 (1天)
    ✓ 编写项目文档
    ✓ 准备演示

路线图已保存到: output/roadmap.json
```

### 1.3 生成代码

```bash
python cli.py generate --project "智能环境监测系统"
```

输出示例：
```
╭─────────────────────────────────────────╮
│      生成项目代码: 智能环境监测系统        │
╰─────────────────────────────────────────╯

✓ 代码生成完成

生成的文件:
  ✓ src/main.ino
  ✓ src/config.h
  ✓ src/dht_driver.ino
  ✓ src/bh1750_driver.ino
  ✓ src/comm_module.ino
  ✓ src/utils.ino

代码已保存到: src/
```

### 1.4 运行完整流程

```bash
python cli.py run --project "智能环境监测系统" --board esp32
```

## 2. 详细功能

### 2.1 需求分析

系统会自动分析项目需求，生成结构化的开发路线图。

**支持的项目类型**:

| 类型 | 关键词 | 推荐硬件 |
|------|--------|---------|
| 环境监测 | 环境、监测、温湿度 | ESP32 + DHT22 + BH1750 |
| 运动控制 | 平衡、运动、电机 | STM32F4 + MPU6050 |
| 智能家居 | 家居、智能、控制 | ESP32 + 继电器 |
| 图像处理 | 图像、摄像头 | ESP32-S3 + OV2640 |
| 气象站 | 气象、天气 | ESP32 + BMP280 |

### 2.2 代码生成

根据路线图自动生成代码，支持：

- Arduino 代码
- ESP-IDF 代码
- STM32 HAL 代码

**生成的代码特性**:

- 遵循 Google 代码规范
- 包含完整错误处理
- 支持看门狗保护
- 串口调试输出
- 详细注释

### 2.3 串口监控

实时监控串口日志，自动检测：

- 系统错误
- 传感器故障
- 通信异常
- 内存溢出
- 看门狗复位

**使用方法**:

```bash
# 列出可用串口
python cli.py monitor

# 监控指定串口
python cli.py monitor --port COM3 --baud 115200

# 监控指定时长
python cli.py monitor --port COM3 --duration 60
```

### 2.4 测试生成

自动生成单元测试用例，支持：

- Unity 测试框架 (C)
- pytest 测试框架 (Python)

**生成的测试**:

- 正常流程测试
- 边界条件测试
- 错误处理测试
- 集成测试

### 2.5 文档生成

自动生成项目文档：

- README.md - 项目说明
- wiring.md - 接线图
- demo-guide.md - 演示指南
- api.md - API 文档
- test-report.md - 测试报告
- troubleshooting.md - 故障排除

## 3. 高级功能

### 3.1 自定义配置

编辑 `config.yaml` 自定义系统配置：

```yaml
# Claude API 配置
claude:
  model: "claude-sonnet-4-20250514"
  max_tokens: 4096
  temperature: 0.3

# 代码生成配置
code_gen:
  style: "google"
  comments: true
  error_handling: true
  watchdog: true

# 测试配置
testing:
  framework: "unity"
  coverage_target: 80
```

### 3.2 添加新平台

1. 在 `config.yaml` 中添加平台配置：

```yaml
platforms:
  new_platform:
    name: "New Platform"
    vendor: "Vendor"
    sdk: "SDK"
    serial_baud: 115200
```

2. 在 `engines/code_gen_engine.py` 中添加代码生成逻辑
3. 在 `engines/requirement_engine.py` 中添加硬件选型规则

### 3.3 添加新传感器

1. 在 `engines/requirement_engine.py` 中添加传感器信息：

```python
self.hardware_db["sensors"]["new_sensor"] = {
    "name": "New Sensor",
    "type": "温度",
    "interface": "I2C",
    "voltage": "3.3V",
    "price": 10,
}
```

2. 在 `engines/code_gen_engine.py` 中添加驱动生成

### 3.4 使用知识库

在 `knowledge-base/` 目录中添加：

- MCU 数据手册
- 传感器库文档
- 最佳实践指南

## 4. 故障排除

### 4.1 常见问题

#### Q1: 依赖安装失败

```bash
# 升级 pip
pip install --upgrade pip

# 使用国内镜像
pip install -r requirements.txt -i https://pypi.tuna.tsinghua.edu.cn/simple
```

#### Q2: 串口连接失败

```bash
# 检查串口权限 (Linux)
sudo usermod -a -G dialout $USER

# 检查串口设备
python -m serial.tools.list_ports
```

#### Q3: 代码生成失败

```bash
# 检查路线图文件
cat output/roadmap.json

# 重新生成路线图
python cli.py init --project "项目名称"
```

### 4.2 日志查看

```bash
# 查看系统日志
tail -f logs/agent-system.log

# 查看串口日志
tail -f logs/serial.log
```

### 4.3 调试模式

```bash
# 启用调试日志
python cli.py --debug init --project "项目名称"

# 查看详细输出
python cli.py --verbose run --project "项目名称"
```

## 5. 最佳实践

### 5.1 项目命名

- 使用简洁明了的项目名称
- 避免特殊字符和空格
- 建议使用中文或英文

### 5.2 硬件选型

- 优先选择常见硬件
- 考虑成本和可获取性
- 预留扩展接口

### 5.3 代码规范

- 遵循 Google 代码规范
- 添加必要注释
- 使用有意义的变量名

### 5.4 测试策略

- 测试覆盖率 > 80%
- 包含边界条件测试
- 测试异常处理

### 5.5 文档维护

- 及时更新文档
- 包含接线图和演示指南
- 记录已知问题

## 6. 示例项目

### 6.1 ESP32 环境监测系统

```bash
python cli.py run --project "基于 ESP32 的智能环境监测系统" --board esp32
```

### 6.2 STM32 平衡车

```bash
python cli.py run --project "基于 STM32 的两轮自平衡车" --board stm32
```

### 6.3 Arduino 气象站

```bash
python cli.py run --project "基于 Arduino 的气象站" --board arduino
```

## 7. 获取帮助

### 7.1 命令帮助

```bash
# 查看所有命令
python cli.py --help

# 查看命令详细帮助
python cli.py init --help
python cli.py run --help
```

### 7.2 文档资源

- [README.md](../README.md) - 项目简介
- [架构文档](architecture.md) - 系统架构
- [API 参考](api-reference.md) - API 文档
- [更新日志](../CHANGELOG.md) - 版本历史

### 7.3 社区支持

- 提交 Issue: https://github.com/your-username/embedded-agent-sys/issues
- 讨论区: https://github.com/your-username/embedded-agent-sys/discussions
