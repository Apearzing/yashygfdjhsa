# 开发者指南

## 1. 开发环境搭建

### 1.1 系统要求

- Python 3.10+
- Git
- Arduino IDE 或 PlatformIO (可选)
- STM32CubeIDE (可选)

### 1.2 克隆项目

```bash
git clone https://github.com/your-username/embedded-agent-sys.git
cd embedded-agent-sys
```

### 1.3 创建虚拟环境

```bash
python -m venv venv

# Linux/Mac
source venv/bin/activate

# Windows
venv\Scripts\activate
```

### 1.4 安装依赖

```bash
pip install -r requirements.txt

# 开发依赖
pip install pytest pytest-cov black pylint mypy
```

### 1.5 配置环境变量

```bash
# 创建 .env 文件
cp .env.example .env

# 编辑 .env 文件
CLAUDE_API_KEY=your_api_key
SERIAL_PORT=COM3
LOG_LEVEL=DEBUG
```

## 2. 项目结构

```
embedded-agent-sys/
├── README.md                    # 项目文档
├── requirements.txt             # Python 依赖
├── config.yaml                  # 系统配置
├── cli.py                       # CLI 入口
├── cli/                         # CLI 模块
│   ├── __init__.py
│   ├── commands.py              # CLI 命令定义
│   └── logger.py                # 日志模块
├── agents/                      # Agent 定义
│   ├── orchestrator.md          # 协调器
│   ├── requirement-agent.md     # 需求拆解 Agent
│   ├── develop-agent.md         # 开发调试 Agent
│   └── verify-agent.md          # 验证文档 Agent
├── engines/                     # 核心引擎
│   ├── __init__.py
│   ├── requirement_engine.py    # 需求解析引擎
│   ├── code_gen_engine.py       # 代码生成引擎
│   ├── serial_monitor.py        # 串口监控引擎
│   ├── test_gen_engine.py       # 测试生成引擎
│   └── doc_gen_engine.py        # 文档生成引擎
├── knowledge-base/              # 知识库
├── schemas/                     # 数据模式
├── templates/                   # 文档模板
├── examples/                    # 示例项目
├── tests/                       # 测试代码
├── logs/                        # 运行日志
└── docs/                        # 项目文档
```

## 3. 核心模块开发

### 3.1 添加新引擎

1. 在 `engines/` 目录创建新文件
2. 实现引擎类
3. 在 `engines/__init__.py` 中导出
4. 在 `cli/commands.py` 中添加命令

**示例**:

```python
# engines/new_engine.py
class NewEngine:
    """新引擎"""

    def __init__(self, config=None):
        self.config = config or {}

    def process(self, input_data):
        """处理数据"""
        # 实现处理逻辑
        return result
```

```python
# engines/__init__.py
from .new_engine import NewEngine

__all__ = [
    # ... 其他引擎
    "NewEngine",
]
```

### 3.2 添加新命令

在 `cli/commands.py` 中添加新命令：

```python
@cli.command()
@click.option("--input", "-i", required=True, help="输入文件")
@click.option("--output", "-o", default="output", help="输出目录")
def new_command(input: str, output: str):
    """新命令说明"""
    from engines.new_engine import NewEngine

    console.print(Panel("[bold blue]执行新命令[/bold blue]"))

    # 读取输入
    with open(input, "r") as f:
        data = f.read()

    # 处理数据
    with console.status("[bold green]处理中..."):
        engine = NewEngine()
        result = engine.process(data)

    # 保存结果
    os.makedirs(output, exist_ok=True)
    with open(os.path.join(output, "result.json"), "w") as f:
        json.dump(result, f, indent=2)

    console.print("[bold green]✓ 完成[/bold green]")
```

### 3.3 添加新传感器支持

1. 在 `engines/requirement_engine.py` 中添加传感器信息：

```python
self.hardware_db["sensors"]["new_sensor"] = {
    "name": "New Sensor",
    "type": "温度",
    "interface": "I2C",
    "voltage": "3.3V",
    "price": 10,
}
```

2. 在 `engines/code_gen_engine.py` 中添加驱动生成：

```python
def _generate_new_sensor_driver(self, platform: str) -> str:
    """生成新传感器驱动"""
    lines = [
        "// New Sensor 驱动",
        "",
        "#include <NewSensor.h>",
        "",
        "void new_sensor_init() {",
        "    // 初始化代码",
        "}",
        "",
        "float new_sensor_read() {",
        "    // 读取代码",
        "    return value;",
        "}",
    ]
    return "\n".join(lines)
```

3. 在 `_generate_sensor_drivers` 方法中添加调用：

```python
def _generate_sensor_drivers(self, hardware, platform):
    files = {}
    for item in hardware:
        if item.get("category") != "sensor":
            continue

        name = item.get("name", "").lower()
        ext = ".ino" if platform == "arduino" else ".c"

        # ... 其他传感器

        if "new_sensor" in name:
            files[f"new_sensor_driver{ext}"] = self._generate_new_sensor_driver(platform)

    return files
```

## 4. 测试

### 4.1 运行测试

```bash
# 运行所有测试
pytest

# 运行带覆盖率的测试
pytest --cov=engines --cov-report=html

# 运行特定测试
pytest tests/test_requirement_engine.py
```

### 4.2 编写测试

在 `tests/` 目录创建测试文件：

```python
# tests/test_new_engine.py
import pytest
from engines.new_engine import NewEngine

@pytest.fixture
def engine():
    """创建引擎实例"""
    return NewEngine()

def test_process_success(engine):
    """测试正常处理"""
    result = engine.process("test input")
    assert result is not None
    assert "key" in result

def test_process_error(engine):
    """测试错误处理"""
    with pytest.raises(ValueError):
        engine.process(None)
```

### 4.3 测试覆盖率

```bash
# 生成覆盖率报告
pytest --cov=engines --cov-report=html

# 查看报告
open htmlcov/index.html
```

## 5. 代码规范

### 5.1 代码风格

使用 Black 格式化代码：

```bash
# 格式化所有文件
black .

# 检查格式
black --check .
```

### 5.2 代码检查

使用 pylint 检查代码：

```bash
# 检查所有文件
pylint engines/

# 检查特定文件
pylint engines/new_engine.py
```

### 5.3 类型检查

使用 mypy 进行类型检查：

```bash
mypy engines/
```

## 6. 文档编写

### 6.1 API 文档

使用 docstring 编写 API 文档：

```python
def process(self, input_data: str) -> Dict[str, Any]:
    """
    处理输入数据

    Args:
        input_data: 输入数据字符串

    Returns:
        处理结果字典

    Raises:
        ValueError: 输入数据无效

    Examples:
        >>> engine = NewEngine()
        >>> result = engine.process("test")
        >>> print(result)
        {'status': 'success'}
    """
    pass
```

### 6.2 用户文档

在 `docs/` 目录编写用户文档：

- `user-guide.md` - 用户指南
- `developer-guide.md` - 开发者指南
- `api-reference.md` - API 参考

### 6.3 更新日志

在 `CHANGELOG.md` 中记录版本更新：

```markdown
## [1.1.0] - 2026-05-07

### 新增
- 添加新传感器支持
- 添加新命令

### 修复
- 修复串口连接问题
- 修复代码生成错误
```

## 7. 发布流程

### 7.1 版本号规范

使用语义化版本号：

- 主版本号: 重大功能更新
- 次版本号: 新功能添加
- 修订号: Bug 修复

### 7.2 发布步骤

1. 更新版本号
2. 更新 CHANGELOG.md
3. 运行测试
4. 提交代码
5. 创建标签
6. 发布

```bash
# 更新版本号
# 编辑 config.yaml 中的 version

# 运行测试
pytest

# 提交代码
git add .
git commit -m "release: v1.1.0"

# 创建标签
git tag -a v1.1.0 -m "Release v1.1.0"

# 推送
git push origin main --tags
```

## 8. 贡献指南

### 8.1 提交 Issue

- 使用 Issue 模板
- 提供详细描述
- 包含复现步骤
- 附上日志信息

### 8.2 提交 Pull Request

1. Fork 项目
2. 创建特性分支
3. 提交更改
4. 编写测试
5. 更新文档
6. 提交 PR

### 8.3 代码审查

- 代码风格检查
- 测试覆盖率检查
- 文档完整性检查
- 功能正确性验证

## 9. 常见开发问题

### 9.1 导入错误

```bash
# 确保在项目根目录
cd embedded-agent-sys

# 确保虚拟环境激活
source venv/bin/activate

# 确保依赖安装
pip install -r requirements.txt
```

### 9.2 测试失败

```bash
# 查看详细错误
pytest -v

# 查看失败测试
pytest --tb=short
```

### 9.3 代码格式问题

```bash
# 自动格式化
black .

# 手动修复
pylint --disable=all --enable=unused-import engines/
```

## 10. 资源链接

- [Python 文档](https://docs.python.org/3/)
- [Click 文档](https://click.palletsprojects.com/)
- [Rich 文档](https://rich.readthedocs.io/)
- [pytest 文档](https://docs.pytest.org/)
- [Arduino 文档](https://www.arduino.cc/reference/en/)
- [ESP-IDF 文档](https://docs.espressif.com/projects/esp-idf/en/latest/esp32/)
