# API 参考文档

## 1. 需求解析引擎 (RequirementEngine)

### 1.1 初始化

```python
from engines.requirement_engine import RequirementEngine

engine = RequirementEngine(config_path="config.yaml")
```

### 1.2 parse_requirement

解析项目需求，生成路线图。

**签名**:
```python
def parse_requirement(
    self,
    project_name: str,
    description: str,
    constraints: Optional[Dict] = None
) -> Dict[str, Any]
```

**参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| project_name | str | 是 | 项目名称 |
| description | str | 是 | 项目描述 |
| constraints | Dict | 否 | 约束条件 |

**返回值**:

```json
{
  "project_id": "proj_001",
  "project_name": "智能环境监测系统",
  "description": "基于 ESP32 的环境监测系统",
  "project_type": "environment",
  "created_at": "2026-05-06T10:00:00",
  "constraints": {
    "budget": 200,
    "board": "ESP32"
  },
  "hardware_list": [...],
  "phases": [...],
  "estimated_days": 4,
  "total_cost": 100,
  "risks": [...]
}
```

**示例**:

```python
engine = RequirementEngine()
roadmap = engine.parse_requirement(
    project_name="智能环境监测系统",
    description="基于 ESP32 采集温湿度、光照、空气质量数据",
    constraints={"budget": 200, "board": "ESP32"}
)
print(json.dumps(roadmap, indent=2, ensure_ascii=False))
```

---

## 2. 代码生成引擎 (CodeGenEngine)

### 2.1 初始化

```python
from engines.code_gen_engine import CodeGenEngine

engine = CodeGenEngine(config={
    "style": "google",
    "comments": True,
    "error_handling": True,
    "watchdog": True
})
```

### 2.2 generate_project

根据路线图生成项目代码。

**签名**:
```python
def generate_project(
    self,
    roadmap: Dict[str, Any],
    output_dir: str = "src"
) -> Dict[str, str]
```

**参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| roadmap | Dict | 是 | 需求路线图 |
| output_dir | str | 否 | 输出目录 |

**返回值**:

```python
{
    "src/main.ino": "// 主程序代码",
    "src/config.h": "// 配置文件",
    "src/dht_driver.ino": "// DHT 传感器驱动",
    "src/bh1750_driver.ino": "// BH1750 驱动",
    "src/comm_module.ino": "// 通信模块",
    "src/utils.ino": "// 工具函数"
}
```

**示例**:

```python
engine = CodeGenEngine()
files = engine.generate_project(roadmap, output_dir="src")
for filepath, content in files.items():
    print(f"Generated: {filepath}")
```

---

## 3. 串口监控引擎 (SerialMonitor)

### 3.1 初始化

```python
from engines.serial_monitor import SerialMonitor

monitor = SerialMonitor(
    port="COM3",
    baudrate=115200,
    timeout=1.0,
    log_file="logs/serial.log"
)
```

### 3.2 list_ports

列出可用串口。

**签名**:
```python
@staticmethod
def list_ports() -> List[Dict[str, str]]
```

**返回值**:

```python
[
    {
        "device": "COM3",
        "description": "USB Serial Port",
        "hwid": "USB VID:PID=1A86:7523"
    }
]
```

### 3.3 connect

连接串口。

**签名**:
```python
def connect(self) -> bool
```

**返回值**: 连接是否成功

### 3.4 disconnect

断开串口连接。

**签名**:
```python
def disconnect(self)
```

### 3.5 add_callback

添加回调函数。

**签名**:
```python
def add_callback(self, callback: Callable)
```

**回调函数签名**:

```python
def callback(log_entry: Dict):
    """
    log_entry = {
        "timestamp": "2026-05-06T10:00:00",
        "level": "INFO",
        "tag": "system",
        "message": "System started",
        "raw": "[INFO] System started"
    }
    """
    pass
```

### 3.6 start

开始监控。

**签名**:
```python
def start(self, background: bool = True)
```

**参数**:

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| background | bool | True | 是否后台运行 |

### 3.7 stop

停止监控。

**签名**:
```python
def stop(self)
```

### 3.8 send_command

发送串口命令。

**签名**:
```python
def send_command(self, command: str)
```

### 3.9 get_logs

获取日志。

**签名**:
```python
def get_logs(self, level: Optional[str] = None, limit: int = 100) -> List[Dict]
```

### 3.10 get_statistics

获取统计信息。

**签名**:
```python
def get_statistics(self) -> Dict
```

**返回值**:

```python
{
    "total_logs": 100,
    "total_errors": 5,
    "total_data_points": 20,
    "level_counts": {
        "INFO": 80,
        "ERROR": 5,
        "WARN": 10,
        "DEBUG": 5
    },
    "error_rate": 0.05
}
```

---

## 4. 测试生成引擎 (TestGenEngine)

### 4.1 初始化

```python
from engines.test_gen_engine import TestGenEngine

engine = TestGenEngine(framework="unity")
```

### 4.2 generate_tests

根据代码生成测试用例。

**签名**:
```python
def generate_tests(
    self,
    code_files: Dict[str, str],
    output_dir: str = "tests"
) -> Dict[str, str]
```

**参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| code_files | Dict | 是 | 代码文件字典 |
| output_dir | str | 否 | 输出目录 |

**返回值**:

```python
{
    "tests/test_main.ino": "// 测试代码",
    "tests/test_sensor_driver.ino": "// 传感器测试",
    "tests/test_runner.c": "// 测试运行器",
    "tests/test_report.md": "# 测试报告模板"
}
```

### 4.3 analyze_coverage

分析测试覆盖率。

**签名**:
```python
def analyze_coverage(self, test_results: Dict[str, Any]) -> Dict[str, Any]
```

**返回值**:

```python
{
    "total_tests": 12,
    "passed": 10,
    "failed": 2,
    "skipped": 0,
    "coverage_percent": 83.33,
    "status": "FAIL"
}
```

---

## 5. 文档生成引擎 (DocGenEngine)

### 5.1 初始化

```python
from engines.doc_gen_engine import DocGenEngine

engine = DocGenEngine(language="zh-CN")
```

### 5.2 generate_docs

生成完整项目文档。

**签名**:
```python
def generate_docs(
    self,
    roadmap: Dict[str, Any],
    code_files: Dict[str, str],
    test_results: Optional[Dict[str, Any]] = None,
    output_dir: str = "docs"
) -> Dict[str, str]
```

**参数**:

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| roadmap | Dict | 是 | 需求路线图 |
| code_files | Dict | 是 | 代码文件 |
| test_results | Dict | 否 | 测试结果 |
| output_dir | str | 否 | 输出目录 |

**返回值**:

```python
{
    "docs/README.md": "# 项目说明文档",
    "docs/wiring.md": "# 接线图",
    "docs/demo-guide.md": "# 演示指南",
    "docs/api.md": "# API 文档",
    "docs/test-report.md": "# 测试报告",
    "docs/troubleshooting.md": "# 故障排除指南"
}
```

---

## 6. CLI 命令

### 6.1 init

初始化新项目。

```bash
python cli.py init --project "智能环境监测系统" --board esp32 --budget 200
```

**参数**:

| 参数 | 简写 | 必填 | 默认值 | 说明 |
|------|------|------|--------|------|
| --project | -p | 是 | - | 项目名称 |
| --board | -b | 否 | esp32 | 目标开发板 |
| --budget | - | 否 | 200 | 预算上限 |

### 6.2 generate

生成项目代码。

```bash
python cli.py generate --project "智能环境监测系统" --board esp32 --output src
```

### 6.3 monitor

启动串口监控。

```bash
python cli.py monitor --port COM3 --baud 115200 --duration 0
```

### 6.4 test

生成测试用例。

```bash
python cli.py test --code-dir src --output tests --framework unity
```

### 6.5 docs

生成项目文档。

```bash
python cli.py docs --roadmap output/roadmap.json --code-dir src --output docs
```

### 6.6 run

运行完整流程。

```bash
python cli.py run --project "智能环境监测系统" --board esp32 --budget 200
```

### 6.7 status

查看系统状态。

```bash
python cli.py status
```
