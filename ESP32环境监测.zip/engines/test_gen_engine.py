"""
测试生成引擎 - 自动生成单元测试用例
"""

import json
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional


class TestGenEngine:
    """测试生成引擎"""

    def __init__(self, framework: str = "unity"):
        """
        初始化测试生成引擎

        Args:
            framework: 测试框架 (unity/pytest)
        """
        self.framework = framework

    def generate_tests(
        self, code_files: Dict[str, str], output_dir: str = "tests"
    ) -> Dict[str, str]:
        """
        根据代码生成测试用例

        Args:
            code_files: 代码文件字典 {文件名: 内容}
            output_dir: 输出目录

        Returns:
            生成的测试文件字典
        """
        test_files = {}

        for filename, content in code_files.items():
            if filename.endswith((".c", ".ino", ".cpp")):
                # 分析代码，提取函数
                functions = self._extract_functions(content)

                # 生成测试文件
                test_filename = f"test_{filename}"
                test_content = self._generate_test_file(filename, functions)
                test_files[test_filename] = test_content

        # 生成测试运行器
        runner_content = self._generate_runner(test_files)
        test_files["test_runner.c" if self.framework == "unity" else "conftest.py"] = runner_content

        # 生成测试报告模板
        report_content = self._generate_report_template()
        test_files["test_report.md"] = report_content

        # 写入文件
        os.makedirs(output_dir, exist_ok=True)
        for filename, content in test_files.items():
            filepath = os.path.join(output_dir, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)

        return {os.path.join(output_dir, k): v for k, v in test_files.items()}

    def _extract_functions(self, code: str) -> List[Dict[str, Any]]:
        """提取函数定义"""
        functions = []

        # 匹配 C/C++ 函数定义
        pattern = r"(?:(?:void|int|float|bool|char|unsigned|static|const)\s+)+(\w+)\s*\(([^)]*)\)\s*\{"
        matches = re.finditer(pattern, code)

        for match in matches:
            func_name = match.group(1)
            params = match.group(2)

            # 跳过 main 函数和常见的非测试函数
            if func_name in ["main", "setup", "loop", "if", "while", "for"]:
                continue

            # 解析参数
            param_list = []
            if params.strip():
                for param in params.split(","):
                    param = param.strip()
                    if param:
                        parts = param.split()
                        if len(parts) >= 2:
                            param_list.append({
                                "type": " ".join(parts[:-1]),
                                "name": parts[-1],
                            })

            functions.append({
                "name": func_name,
                "params": param_list,
                "return_type": "void",  # 简化处理
            })

        return functions

    def _generate_test_file(self, source_file: str, functions: List[Dict]) -> str:
        """生成测试文件"""
        if self.framework == "unity":
            return self._generate_unity_tests(source_file, functions)
        else:
            return self._generate_pytest_tests(source_file, functions)

    def _generate_unity_tests(self, source_file: str, functions: List[Dict]) -> str:
        """生成 Unity 测试文件"""
        module_name = source_file.replace(".c", "").replace(".ino", "").replace(".cpp", "")

        lines = [
            "// ============================================",
            f"// 测试文件: test_{source_file}",
            f"// 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "// ============================================",
            "",
            '#include "unity.h"',
            f'#include "{source_file}"',
            "",
            "// 测试固件",
            "void setUp(void) {",
            "    // 测试前初始化",
            "}",
            "",
            "void tearDown(void) {",
            "    // 测试后清理",
            "}",
            "",
        ]

        # 为每个函数生成测试用例
        for func in functions:
            func_name = func["name"]

            # 正常流程测试
            lines.extend(
                [
                    f"// 测试 {func_name} 正常流程",
                    f"void test_{func_name}_success(void) {{",
                    f'    TEST_IGNORE_MESSAGE("TODO: Implement test for {func_name}");',
                    "}",
                    "",
                ]
            )

            # 边界条件测试
            lines.extend(
                [
                    f"// 测试 {func_name} 边界条件",
                    f"void test_{func_name}_boundary(void) {{",
                    f'    TEST_IGNORE_MESSAGE("TODO: Implement boundary test for {func_name}");',
                    "}",
                    "",
                ]
            )

            # 错误处理测试
            lines.extend(
                [
                    f"// 测试 {func_name} 错误处理",
                    f"void test_{func_name}_error(void) {{",
                    f'    TEST_IGNORE_MESSAGE("TODO: Implement error test for {func_name}");',
                    "}",
                    "",
                ]
            )

        # 测试运行器
        lines.extend(
            [
                "// 测试运行器",
                "int main(void) {",
                "    UNITY_BEGIN();",
                "",
            ]
        )

        for func in functions:
            func_name = func["name"]
            lines.append(f"    RUN_TEST(test_{func_name}_success);")
            lines.append(f"    RUN_TEST(test_{func_name}_boundary);")
            lines.append(f"    RUN_TEST(test_{func_name}_error);")

        lines.extend(
            [
                "",
                "    return UNITY_END();",
                "}",
            ]
        )

        return "\n".join(lines)

    def _generate_pytest_tests(self, source_file: str, functions: List[Dict]) -> str:
        """生成 pytest 测试文件"""
        module_name = source_file.replace(".py", "")

        lines = [
            '"""',
            f"测试文件: test_{source_file}",
            f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            '"""',
            "",
            "import pytest",
            f"from {module_name} import *",
            "",
            "",
            "@pytest.fixture",
            "def setup():",
            '    """测试固件"""',
            "    # TODO: 初始化测试环境",
            "    yield",
            "    # TODO: 清理测试环境",
            "",
        ]

        # 为每个函数生成测试用例
        for func in functions:
            func_name = func["name"]

            lines.extend(
                [
                    f"class Test{func_name.title()}:",
                    f'    """测试 {func_name}"""',
                    "",
                    f"    def test_{func_name}_success(self, setup):",
                    f'        """测试正常流程"""',
                    "        # TODO: 实现测试",
                    "        pass",
                    "",
                    f"    def test_{func_name}_boundary(self, setup):",
                    f'        """测试边界条件"""',
                    "        # TODO: 实现测试",
                    "        pass",
                    "",
                    f"    def test_{func_name}_error(self, setup):",
                    f'        """测试错误处理"""',
                    "        # TODO: 实现测试",
                    "        pass",
                    "",
                ]
            )

        return "\n".join(lines)

    def _generate_runner(self, test_files: Dict[str, str]) -> str:
        """生成测试运行器"""
        if self.framework == "unity":
            return self._generate_unity_runner(test_files)
        else:
            return self._generate_pytest_runner(test_files)

    def _generate_unity_runner(self, test_files: Dict[str, str]) -> str:
        """生成 Unity 测试运行器"""
        lines = [
            "// ============================================",
            "// Unity 测试运行器",
            f"// 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "// ============================================",
            "",
            "#include <stdio.h>",
            "#include <stdlib.h>",
            "",
            "// 包含所有测试文件",
        ]

        for filename in test_files:
            if filename.endswith(".c") and filename.startswith("test_"):
                lines.append(f'#include "{filename}"')

        lines.extend(
            [
                "",
                "int main(int argc, char *argv[]) {",
                '    printf("========================================\\n");',
                '    printf("嵌入式项目测试套件\\n");',
                f'    printf("生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\\n");',
                '    printf("========================================\\n\\n");',
                "",
                "    return 0;",
                "}",
            ]
        )

        return "\n".join(lines)

    def _generate_pytest_runner(self, test_files: Dict[str, str]) -> str:
        """生成 pytest 配置文件"""
        lines = [
            '"""',
            "pytest 配置文件",
            '"""',
            "",
            "import pytest",
            "",
            "",
            "@pytest.fixture(scope='session')",
            "def setup_session():",
            '    """会话级固件"""',
            "    print('\\n===== 测试会话开始 =====')",
            "    yield",
            "    print('\\n===== 测试会话结束 =====')",
            "",
            "",
            "def pytest_configure(config):",
            '    """pytest 配置"""',
            "    config.addinivalue_line(",
            '        "markers", "slow: 标记慢速测试"',
            "    )",
            "",
            "",
            "def pytest_collection_modifyitems(items):",
            '    """修改测试收集"""',
            "    for item in items:",
            '        if "slow" in item.keywords:',
            "            item.add_marker(pytest.mark.slow)",
        ]

        return "\n".join(lines)

    def _generate_report_template(self) -> str:
        """生成测试报告模板"""
        lines = [
            "# 测试报告",
            "",
            f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## 测试概览",
            "",
            "| 指标 | 数值 |",
            "|------|------|",
            "| 测试用例总数 | 0 |",
            "| 通过数量 | 0 |",
            "| 失败数量 | 0 |",
            "| 跳过数量 | 0 |",
            "| 通过率 | 0% |",
            "| 执行时间 | 0s |",
            "",
            "## 测试详情",
            "",
            "### 通过的测试",
            "",
            "| 测试用例 | 执行时间 |",
            "|---------|---------|",
            "",
            "### 失败的测试",
            "",
            "| 测试用例 | 错误信息 |",
            "|---------|---------|",
            "",
            "## 代码覆盖率",
            "",
            "| 文件 | 语句数 | 未覆盖 | 覆盖率 |",
            "|------|--------|--------|--------|",
            "",
            "## 风险评估",
            "",
            "- [ ] 高风险: 核心功能未测试",
            "- [ ] 中风险: 边界条件未覆盖",
            "- [ ] 低风险: 错误处理不完整",
            "",
            "## 建议",
            "",
            "1. 补充缺失的测试用例",
            "2. 增加边界条件测试",
            "3. 完善错误处理测试",
        ]

        return "\n".join(lines)

    def analyze_coverage(self, test_results: Dict[str, Any]) -> Dict[str, Any]:
        """分析测试覆盖率"""
        total = test_results.get("total", 0)
        passed = test_results.get("passed", 0)
        failed = test_results.get("failed", 0)
        skipped = test_results.get("skipped", 0)

        coverage = (passed / total * 100) if total > 0 else 0

        return {
            "total_tests": total,
            "passed": passed,
            "failed": failed,
            "skipped": skipped,
            "coverage_percent": round(coverage, 2),
            "status": "PASS" if failed == 0 else "FAIL",
        }


if __name__ == "__main__":
    # 测试代码
    engine = TestGenEngine(framework="unity")

    # 模拟代码文件
    code_files = {
        "sensor_driver.c": """
void sensor_init() {
    // 初始化传感器
}

float sensor_read_temperature() {
    // 读取温度
    return 25.0;
}

float sensor_read_humidity() {
    // 读取湿度
    return 60.0;
}

void sensor_calibrate(float offset) {
    // 校准传感器
}
""",
    }

    test_files = engine.generate_tests(code_files, output_dir="test_output")
    for filepath, content in test_files.items():
        print(f"Generated: {filepath}")
