"""
串口监控引擎 - 实时监控串口日志，分析运行状态
"""

import re
import time
import threading
from datetime import datetime
from typing import Callable, Dict, List, Optional

import serial
import serial.tools.list_ports


class SerialMonitor:
    """串口监控引擎"""

    # 日志级别定义
    LOG_LEVELS = {
        "DEBUG": 0,
        "INFO": 1,
        "WARN": 2,
        "ERROR": 3,
        "DATA": 4,
    }

    # 错误模式定义
    ERROR_PATTERNS = {
        "stack_overflow": r"Stack smashing detect",
        "watchdog_reset": r"Task watchdog got triggered",
        "heap_exhausted": r"heap.*corrupt|out of memory",
        "i2c_error": r"I2C.*timeout|NACK",
        "wifi_disconnect": r"WiFi.*disconnect",
        "sensor_error": r"sensor.*fail|read.*error",
        "panic": r"abort\(\)|Guru Meditation",
        "exception": r"Exception|EXCEPTION",
    }

    def __init__(
        self,
        port: str = "COM3",
        baudrate: int = 115200,
        timeout: float = 1.0,
        log_file: Optional[str] = None,
    ):
        """
        初始化串口监控器

        Args:
            port: 串口号
            baudrate: 波特率
            timeout: 超时时间
            log_file: 日志文件路径
        """
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.log_file = log_file

        self.serial_conn = None
        self.running = False
        self.callbacks: List[Callable] = []
        self.log_buffer: List[Dict] = []
        self.error_buffer: List[Dict] = []
        self.data_buffer: List[Dict] = []

        self._lock = threading.Lock()
        self._thread = None

    @staticmethod
    def list_ports() -> List[Dict[str, str]]:
        """列出可用串口"""
        ports = serial.tools.list_ports.comports()
        return [
            {
                "device": port.device,
                "description": port.description,
                "hwid": port.hwid,
            }
            for port in ports
        ]

    def connect(self) -> bool:
        """连接串口"""
        try:
            self.serial_conn = serial.Serial(
                port=self.port,
                baudrate=self.baudrate,
                timeout=self.timeout,
            )
            print(f"[INFO] Connected to {self.port} at {self.baudrate} baud")
            return True
        except serial.SerialException as e:
            print(f"[ERROR] Failed to connect to {self.port}: {e}")
            return False

    def disconnect(self):
        """断开串口连接"""
        self.running = False
        if self._thread:
            self._thread.join(timeout=2)
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.close()
            print(f"[INFO] Disconnected from {self.port}")

    def add_callback(self, callback: Callable):
        """添加回调函数"""
        self.callbacks.append(callback)

    def start(self, background: bool = True):
        """
        开始监控

        Args:
            background: 是否后台运行
        """
        if not self.serial_conn:
            if not self.connect():
                return

        self.running = True

        if background:
            self._thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self._thread.start()
            print("[INFO] Serial monitor started in background")
        else:
            print("[INFO] Serial monitor started (foreground)")
            self._monitor_loop()

    def stop(self):
        """停止监控"""
        self.running = False
        if self._thread:
            self._thread.join(timeout=2)
        print("[INFO] Serial monitor stopped")

    def _monitor_loop(self):
        """监控主循环"""
        while self.running:
            try:
                if self.serial_conn and self.serial_conn.in_waiting:
                    line = self.serial_conn.readline().decode("utf-8", errors="ignore").strip()
                    if line:
                        self._process_line(line)
                else:
                    time.sleep(0.01)
            except serial.SerialException as e:
                print(f"[ERROR] Serial error: {e}")
                self._handle_error(e)
                break
            except Exception as e:
                print(f"[ERROR] Unexpected error: {e}")

    def _process_line(self, line: str):
        """处理一行日志"""
        timestamp = datetime.now()

        # 解析日志
        log_entry = self._parse_log(line, timestamp)

        # 存储到缓冲区
        with self._lock:
            self.log_buffer.append(log_entry)

            # 检测错误
            if self._detect_error(line):
                self.error_buffer.append(log_entry)

            # 提取数据
            data = self._extract_data(line)
            if data:
                self.data_buffer.append(data)

        # 触发回调
        for callback in self.callbacks:
            try:
                callback(log_entry)
            except Exception as e:
                print(f"[ERROR] Callback error: {e}")

        # 输出到控制台
        self._print_log(log_entry)

        # 写入日志文件
        if self.log_file:
            self._write_log(log_entry)

    def _parse_log(self, line: str, timestamp: datetime) -> Dict:
        """解析日志行"""
        # 尝试匹配格式: [LEVEL] [TAG] message
        match = re.match(r"\[(\w+)\]\s*\[(\w+)\]\s*(.*)", line)
        if match:
            return {
                "timestamp": timestamp.isoformat(),
                "level": match.group(1),
                "tag": match.group(2),
                "message": match.group(3),
                "raw": line,
            }

        # 尝试匹配格式: [LEVEL] message
        match = re.match(r"\[(\w+)\]\s*(.*)", line)
        if match:
            return {
                "timestamp": timestamp.isoformat(),
                "level": match.group(1),
                "tag": "system",
                "message": match.group(2),
                "raw": line,
            }

        # 无法解析，作为普通输出
        return {
            "timestamp": timestamp.isoformat(),
            "level": "INFO",
            "tag": "output",
            "message": line,
            "raw": line,
        }

    def _detect_error(self, line: str) -> bool:
        """检测错误模式"""
        for error_type, pattern in self.ERROR_PATTERNS.items():
            if re.search(pattern, line, re.IGNORECASE):
                print(f"[ALERT] Detected {error_type}: {line}")
                return True
        return False

    def _extract_data(self, line: str) -> Optional[Dict]:
        """提取传感器数据"""
        # 匹配格式: [DATA] key1: value1, key2: value2
        match = re.search(r"\[DATA\]\s*(.*)", line)
        if match:
            data_str = match.group(1)
            data = {}

            # 解析 key: value 对
            pairs = re.findall(r"(\w+):\s*([\d.]+)", data_str)
            for key, value in pairs:
                try:
                    data[key] = float(value)
                except ValueError:
                    pass

            if data:
                return {
                    "timestamp": datetime.now().isoformat(),
                    "data": data,
                }

        return None

    def _print_log(self, log_entry: Dict):
        """打印日志到控制台"""
        level = log_entry["level"]
        tag = log_entry["tag"]
        message = log_entry["message"]
        timestamp = log_entry["timestamp"]

        # 颜色定义
        colors = {
            "DEBUG": "\033[90m",  # 灰色
            "INFO": "\033[92m",   # 绿色
            "WARN": "\033[93m",   # 黄色
            "ERROR": "\033[91m",  # 红色
            "DATA": "\033[94m",   # 蓝色
        }
        reset = "\033[0m"

        color = colors.get(level, "")
        print(f"{color}[{timestamp}] [{level}] [{tag}] {message}{reset}")

    def _write_log(self, log_entry: Dict):
        """写入日志文件"""
        with open(self.log_file, "a", encoding="utf-8") as f:
            f.write(f"[{log_entry['timestamp']}] [{log_entry['level']}] [{log_entry['tag']}] {log_entry['message']}\n")

    def _handle_error(self, error: Exception):
        """处理串口错误"""
        self.disconnect()

    def send_command(self, command: str):
        """发送串口命令"""
        if self.serial_conn and self.serial_conn.is_open:
            self.serial_conn.write(f"{command}\n".encode())
            print(f"[INFO] Sent command: {command}")

    def get_logs(self, level: Optional[str] = None, limit: int = 100) -> List[Dict]:
        """获取日志"""
        with self._lock:
            if level:
                filtered = [log for log in self.log_buffer if log["level"] == level]
            else:
                filtered = self.log_buffer.copy()

            return filtered[-limit:]

    def get_errors(self, limit: int = 50) -> List[Dict]:
        """获取错误日志"""
        with self._lock:
            return self.error_buffer[-limit:]

    def get_data(self, limit: int = 100) -> List[Dict]:
        """获取传感器数据"""
        with self._lock:
            return self.data_buffer[-limit:]

    def clear_buffers(self):
        """清空缓冲区"""
        with self._lock:
            self.log_buffer.clear()
            self.error_buffer.clear()
            self.data_buffer.clear()

    def get_statistics(self) -> Dict:
        """获取统计信息"""
        with self._lock:
            total = len(self.log_buffer)
            errors = len(self.error_buffer)
            data_points = len(self.data_buffer)

            level_counts = {}
            for log in self.log_buffer:
                level = log["level"]
                level_counts[level] = level_counts.get(level, 0) + 1

            return {
                "total_logs": total,
                "total_errors": errors,
                "total_data_points": data_points,
                "level_counts": level_counts,
                "error_rate": errors / total if total > 0 else 0,
            }


def log_callback(log_entry: Dict):
    """示例回调函数"""
    if log_entry["level"] == "ERROR":
        print(f"  [CALLBACK] Error detected: {log_entry['message']}")


if __name__ == "__main__":
    # 列出可用串口
    print("Available serial ports:")
    for port in SerialMonitor.list_ports():
        print(f"  {port['device']}: {port['description']}")

    # 测试监控器
    monitor = SerialMonitor(port="COM3", baudrate=115200)
    monitor.add_callback(log_callback)

    try:
        monitor.start(background=False)
    except KeyboardInterrupt:
        print("\nStopping monitor...")
        monitor.stop()
