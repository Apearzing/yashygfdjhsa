"""
代码生成引擎 - 根据路线图生成嵌入式代码
"""

import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional


class CodeGenEngine:
    """代码生成引擎"""

    def __init__(self, config: Optional[Dict] = None):
        """初始化引擎"""
        self.config = config or {}
        self.style = self.config.get("style", "google")
        self.comments = self.config.get("comments", True)
        self.error_handling = self.config.get("error_handling", True)
        self.watchdog = self.config.get("watchdog", True)

    def generate_project(
        self, roadmap: Dict[str, Any], output_dir: str = "src"
    ) -> Dict[str, str]:
        """
        根据路线图生成项目代码

        Args:
            roadmap: 需求路线图
            output_dir: 输出目录

        Returns:
            生成的文件路径字典
        """
        project_type = roadmap.get("project_type", "general")
        hardware = roadmap.get("hardware_list", [])

        # 确定目标平台
        platform = self._detect_platform(hardware)

        # 生成代码文件
        files = {}

        # 主程序
        main_code = self._generate_main(project_type, hardware, platform)
        files["main.ino" if platform == "arduino" else "main.c"] = main_code

        # 配置文件
        config_code = self._generate_config(hardware, platform)
        files["config.h"] = config_code

        # 传感器驱动
        sensor_files = self._generate_sensor_drivers(hardware, platform)
        files.update(sensor_files)

        # 通信模块
        comm_code = self._generate_comm_module(project_type, platform)
        files["comm_module.c" if platform != "arduino" else "comm_module.ino"] = comm_code

        # 工具模块
        util_code = self._generate_util_module(platform)
        files["utils.c" if platform != "arduino" else "utils.ino"] = util_code

        # 写入文件
        os.makedirs(output_dir, exist_ok=True)
        for filename, content in files.items():
            filepath = os.path.join(output_dir, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)

        return {os.path.join(output_dir, k): v for k, v in files.items()}

    def _detect_platform(self, hardware: List[Dict]) -> str:
        """检测目标平台"""
        for item in hardware:
            if item.get("category") == "mcu":
                name = item.get("name", "").lower()
                if "esp32" in name:
                    return "esp32"
                elif "stm32" in name:
                    return "stm32"
                elif "arduino" in name:
                    return "arduino"
        return "esp32"  # 默认

    def _generate_main(
        self, project_type: str, hardware: List[Dict], platform: str
    ) -> str:
        """生成主程序"""
        if platform == "arduino":
            return self._generate_arduino_main(project_type, hardware)
        else:
            return self._generate_esp_idf_main(project_type, hardware)

    def _generate_arduino_main(
        self, project_type: str, hardware: List[Dict]
    ) -> str:
        """生成 Arduino 主程序"""
        includes = []
        init_calls = []
        loop_calls = []

        # 根据硬件添加头文件和初始化
        for item in hardware:
            category = item.get("category")
            name = item.get("name", "").lower()

            if category == "sensor":
                if "dht" in name:
                    includes.append("#include <DHT.h>")
                    init_calls.append("    dht.begin();")
                    loop_calls.append("    float temp = dht.readTemperature();")
                    loop_calls.append("    float humidity = dht.readHumidity();")
                elif "bh1750" in name:
                    includes.append("#include <BH1750.h>")
                    init_calls.append("    lightSensor.begin();")
                    loop_calls.append("    float light = lightSensor.readLightLevel();")
                elif "mpu6050" in name:
                    includes.append("#include <MPU6050.h>")
                    init_calls.append("    mpu.begin();")
                    loop_calls.append("    mpu.getAcceleration(&ax, &ay, &az);")
            elif category == "display":
                if "ssd1306" in name:
                    includes.append("#include <Adafruit_SSD1306.h>")
                    init_calls.append("    display.begin(SSD1306_SWITCHCAPVCC, 0x3C);")
                    loop_calls.append("    display.clearDisplay();")
                    loop_calls.append("    display.display();")

        # 基础包含
        base_includes = [
            "#include <Arduino.h>",
            "#include <WiFi.h>",
            "",
        ]

        # 配置定义
        config_defs = [
            "// 配置定义",
            '#define WIFI_SSID "your_ssid"',
            '#define WIFI_PASS "your_password"',
            "#define SERIAL_BAUD 115200",
            "#define UPDATE_INTERVAL 5000",
            "",
        ]

        # 全局变量
        globals_def = [
            "// 全局变量",
            "unsigned long lastUpdate = 0;",
            "",
        ]

        # 组装代码
        lines = [
            "// ============================================",
            "// 嵌入式竞赛项目 - 自动生成代码",
            f"// 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "// ============================================",
            "",
        ]
        lines.extend(base_includes)
        lines.extend(includes)
        lines.extend(config_defs)
        lines.extend(globals_def)

        # setup 函数
        lines.extend(
            [
                "void setup() {",
                "    Serial.begin(SERIAL_BAUD);",
                "    Serial.println('[INFO] System starting...');",
                "",
                "    // 初始化硬件",
            ]
        )
        lines.extend(init_calls)
        lines.extend(
            [
                "",
                "    // 初始化 WiFi",
                "    initWiFi();",
                "",
                '    Serial.println("[INFO] System initialized");',
                "}",
                "",
            ]
        )

        # loop 函数
        lines.extend(
            [
                "void loop() {",
                "    if (millis() - lastUpdate >= UPDATE_INTERVAL) {",
                "        lastUpdate = millis();",
                "",
                "        // 读取传感器数据",
            ]
        )
        lines.extend(loop_calls)
        lines.extend(
            [
                "",
                "        // 处理数据",
                "        processData();",
                "",
                "        // 上传数据",
                "        uploadData();",
                "    }",
                "",
                "    // 处理串口命令",
                "    handleSerialCommand();",
                "",
                "    delay(10);",
                "}",
                "",
            ]
        )

        # 辅助函数
        lines.extend(
            [
                "void initWiFi() {",
                "    WiFi.begin(WIFI_SSID, WIFI_PASS);",
                "    while (WiFi.status() != WL_CONNECTED) {",
                "        delay(500);",
                '        Serial.print(".");',
                "    }",
                '    Serial.println("\\n[INFO] WiFi connected");',
                '    Serial.print("[INFO] IP: ");',
                "    Serial.println(WiFi.localIP());",
                "}",
                "",
                "void processData() {",
                "    // TODO: 实现数据处理逻辑",
                "}",
                "",
                "void uploadData() {",
                "    // TODO: 实现数据上传逻辑",
                "}",
                "",
                "void handleSerialCommand() {",
                "    if (Serial.available()) {",
                "        String cmd = Serial.readStringUntil('\\n');",
                '        cmd.trim();',
                "",
                '        if (cmd == "status") {',
                '            Serial.println("[INFO] System running");',
                '        } else if (cmd == "restart") {',
                "            ESP.restart();",
                "        }",
                "    }",
                "}",
            ]
        )

        return "\n".join(lines)

    def _generate_esp_idf_main(
        self, project_type: str, hardware: List[Dict]
    ) -> str:
        """生成 ESP-IDF 主程序"""
        lines = [
            "// ============================================",
            "// 嵌入式竞赛项目 - ESP-IDF 自动生成代码",
            f"// 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "// ============================================",
            "",
            '#include <stdio.h>',
            '#include "freertos/FreeRTOS.h"',
            '#include "freertos/task.h"',
            '#include "esp_system.h"',
            '#include "esp_wifi.h"',
            '#include "esp_log.h"',
            '#include "nvs_flash.h"',
            "",
            'static const char *TAG = "main";',
            "",
            "void app_main(void) {",
            '    ESP_LOGI(TAG, "System starting...");',
            "",
            "    // 初始化 NVS",
            "    esp_err_t ret = nvs_flash_init();",
            "    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {",
            "        ESP_ERROR_CHECK(nvs_flash_erase());",
            "        ret = nvs_flash_init();",
            "    }",
            "    ESP_ERROR_CHECK(ret);",
            "",
            '    ESP_LOGI(TAG, "System initialized");',
            "",
            "    // 主循环",
            "    while (1) {",
            "        // 处理业务逻辑",
            "        vTaskDelay(pdMS_TO_TICKS(1000));",
            "    }",
            "}",
        ]

        return "\n".join(lines)

    def _generate_config(self, hardware: List[Dict], platform: str) -> str:
        """生成配置文件"""
        lines = [
            "// ============================================",
            "// 项目配置文件",
            f"// 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "// ============================================",
            "",
            "#ifndef CONFIG_H",
            "#define CONFIG_H",
            "",
            "// WiFi 配置",
            '#define WIFI_SSID "your_ssid"',
            '#define WIFI_PASS "your_password"',
            "",
            "// 串口配置",
            "#define SERIAL_BAUD 115200",
            "",
            "// 更新间隔 (ms)",
            "#define UPDATE_INTERVAL 5000",
            "",
            "// 引脚定义",
        ]

        # 根据硬件添加引脚定义
        pin = 2
        for item in hardware:
            category = item.get("category")
            name = item.get("name", "").upper()

            if category == "sensor":
                lines.append(f"#define {name}_PIN {pin}")
                pin += 1
            elif category == "display":
                lines.append(f"#define SDA_PIN 21")
                lines.append(f"#define SCL_PIN 22")

        lines.extend(
            [
                "",
                "// 调试配置",
                "#define DEBUG_ENABLED 1",
                "#define LOG_LEVEL LOG_INFO",
                "",
                "#endif // CONFIG_H",
            ]
        )

        return "\n".join(lines)

    def _generate_sensor_drivers(
        self, hardware: List[Dict], platform: str
    ) -> Dict[str, str]:
        """生成传感器驱动"""
        files = {}

        for item in hardware:
            if item.get("category") != "sensor":
                continue

            name = item.get("name", "").lower()
            ext = ".ino" if platform == "arduino" else ".c"

            if "dht" in name:
                files[f"dht_driver{ext}"] = self._generate_dht_driver(platform)
            elif "bh1750" in name:
                files[f"bh1750_driver{ext}"] = self._generate_bh1750_driver(platform)
            elif "mpu6050" in name:
                files[f"mpu6050_driver{ext}"] = self._generate_mpu6050_driver(platform)

        return files

    def _generate_dht_driver(self, platform: str) -> str:
        """生成 DHT 传感器驱动"""
        lines = [
            "// DHT 温湿度传感器驱动",
            "",
            "#include <DHT.h>",
            "",
            "#define DHT_PIN 4",
            "#define DHT_TYPE DHT22",
            "",
            "DHT dht(DHT_PIN, DHT_TYPE);",
            "",
            "void dht_init() {",
            "    dht.begin();",
            '    Serial.println("[INFO] DHT sensor initialized");',
            "}",
            "",
            "float dht_read_temperature() {",
            "    float temp = dht.readTemperature();",
            "    if (isnan(temp)) {",
            '        Serial.println("[ERROR] Failed to read temperature");',
            "        return -999.0;",
            "    }",
            "    return temp;",
            "}",
            "",
            "float dht_read_humidity() {",
            "    float hum = dht.readHumidity();",
            "    if (isnan(hum)) {",
            '        Serial.println("[ERROR] Failed to read humidity");',
            "        return -999.0;",
            "    }",
            "    return hum;",
            "}",
        ]

        return "\n".join(lines)

    def _generate_bh1750_driver(self, platform: str) -> str:
        """生成 BH1750 光照传感器驱动"""
        lines = [
            "// BH1750 光照传感器驱动",
            "",
            "#include <BH1750.h>",
            "#include <Wire.h>",
            "",
            "BH1750 lightSensor;",
            "",
            "void bh1750_init() {",
            "    lightSensor.begin();",
            '    Serial.println("[INFO] BH1750 sensor initialized");',
            "}",
            "",
            "float bh1750_read_light() {",
            "    float lux = lightSensor.readLightLevel();",
            "    if (lux < 0) {",
            '        Serial.println("[ERROR] Failed to read light level");',
            "        return -999.0;",
            "    }",
            "    return lux;",
            "}",
        ]

        return "\n".join(lines)

    def _generate_mpu6050_driver(self, platform: str) -> str:
        """生成 MPU6050 IMU 驱动"""
        lines = [
            "// MPU6050 六轴 IMU 驱动",
            "",
            "#include <MPU6050_tockn.h>",
            "#include <Wire.h>",
            "",
            "MPU6050 mpu(Wire);",
            "",
            "void mpu6050_init() {",
            "    mpu.begin();",
            "    mpu.calcGyroOffsets(true);",
            '    Serial.println("[INFO] MPU6050 sensor initialized");',
            "}",
            "",
            "void mpu6050_read(float *ax, float *ay, float *az, float *gx, float *gy, float *gz) {",
            "    mpu.update();",
            "    *ax = mpu.getAccX();",
            "    *ay = mpu.getAccY();",
            "    *az = mpu.getAccZ();",
            "    *gx = mpu.getGyroX();",
            "    *gy = mpu.getGyroY();",
            "    *gz = mpu.getGyroZ();",
            "}",
        ]

        return "\n".join(lines)

    def _generate_comm_module(self, project_type: str, platform: str) -> str:
        """生成通信模块"""
        lines = [
            "// 通信模块",
            "",
            "#include <WiFi.h>",
            "#include <HTTPClient.h>",
            "",
            "// WiFi 配置",
            'const char *ssid = "your_ssid";',
            'const char *password = "your_password";',
            "",
            "// 服务器配置",
            'const char *server_url = "http://your-server.com/api/data";',
            "",
            "void wifi_init() {",
            "    WiFi.begin(ssid, password);",
            "    while (WiFi.status() != WL_CONNECTED) {",
            "        delay(500);",
            '        Serial.print(".");',
            "    }",
            '    Serial.println("\\n[INFO] WiFi connected");',
            '    Serial.print("[INFO] IP: ");',
            "    Serial.println(WiFi.localIP());",
            "}",
            "",
            "bool upload_data(float temp, float humidity, float light) {",
            "    if (WiFi.status() != WL_CONNECTED) {",
            '        Serial.println("[WARN] WiFi not connected");',
            "        return false;",
            "    }",
            "",
            "    HTTPClient http;",
            "    http.begin(server_url);",
            '    http.addHeader("Content-Type", "application/json");',
            "",
            "    String json = \"{";
            json_parts = []
            json_parts.append('"temperature":' + String(temp))
            json_parts.append('"humidity":' + String(humidity))
            json_parts.append('"light":' + String(light))
            "}\";",
            "",
            "    int httpResponseCode = http.POST(json);",
            "",
            "    if (httpResponseCode > 0) {",
            '        Serial.printf("[INFO] HTTP Response: %d\\n", httpResponseCode);',
            "        http.end();",
            "        return true;",
            "    } else {",
            '        Serial.printf("[ERROR] HTTP Error: %s\\n", http.errorToString(httpResponseCode).c_str());',
            "        http.end();",
            "        return false;",
            "    }",
            "}",
        ]

        return "\n".join(lines)

    def _generate_util_module(self, platform: str) -> str:
        """生成工具模块"""
        lines = [
            "// 工具模块",
            "",
            "#include <Arduino.h>",
            "",
            "// 日志级别",
            "#define LOG_DEBUG 0",
            "#define LOG_INFO 1",
            "#define LOG_WARN 2",
            "#define LOG_ERROR 3",
            "",
            "#define LOG_LEVEL LOG_INFO",
            "",
            "void log_message(int level, const char *tag, const char *format, ...) {",
            "    if (level < LOG_LEVEL) return;",
            "",
            '    const char *level_str[] = {"DEBUG", "INFO", "WARN", "ERROR"};',
            "",
            "    char buffer[256];",
            "    va_list args;",
            "    va_start(args, format);",
            "    vsnprintf(buffer, sizeof(buffer), format, args);",
            "    va_end(args);",
            "",
            '    Serial.printf("[%s] [%s] %s\\n', level_str[level], tag, buffer);',
            "}",
            "",
            "// 看门狗配置",
            "void watchdog_init(int timeout_ms) {",
            "    // ESP32 看门狗初始化",
            "}",
            "",
            "void watchdog_reset() {",
            "    // 喂狗",
            "}",
            "",
            "// 内存监控",
            "void print_memory_info() {",
            '    Serial.printf("[INFO] Free heap: %d bytes\\n', ESP.getFreeHeap());',
            '    Serial.printf("[INFO] Min free heap: %d bytes\\n', ESP.getMinFreeHeap());',
            "}",
        ]

        return "\n".join(lines)


if __name__ == "__main__":
    # 测试代码
    engine = CodeGenEngine()

    # 模拟路线图
    roadmap = {
        "project_type": "environment",
        "hardware_list": [
            {"category": "mcu", "name": "ESP32"},
            {"category": "sensor", "name": "DHT22"},
            {"category": "sensor", "name": "BH1750"},
            {"category": "display", "name": "SSD1306"},
        ],
    }

    files = engine.generate_project(roadmap, output_dir="test_output")
    for filepath, content in files.items():
        print(f"Generated: {filepath}")
