"""
文档生成引擎 - 自动生成项目文档、接线图、演示指南
"""

import json
import os
from datetime import datetime
from typing import Any, Dict, List, Optional


class DocGenEngine:
    """文档生成引擎"""

    def __init__(self, language: str = "zh-CN"):
        """
        初始化文档生成引擎

        Args:
            language: 文档语言
        """
        self.language = language

    def generate_docs(
        self,
        roadmap: Dict[str, Any],
        code_files: Dict[str, str],
        test_results: Optional[Dict[str, Any]] = None,
        output_dir: str = "docs",
    ) -> Dict[str, str]:
        """
        生成完整项目文档

        Args:
            roadmap: 需求路线图
            code_files: 代码文件
            test_results: 测试结果
            output_dir: 输出目录

        Returns:
            生成的文档文件字典
        """
        docs = {}

        # 生成项目说明文档
        docs["README.md"] = self._generate_readme(roadmap, code_files)

        # 生成接线图
        docs["wiring.md"] = self._generate_wiring(roadmap.get("hardware_list", []))

        # 生成演示指南
        docs["demo-guide.md"] = self._generate_demo_guide(roadmap, code_files)

        # 生成 API 文档
        docs["api.md"] = self._generate_api_doc(code_files)

        # 生成测试报告
        if test_results:
            docs["test-report.md"] = self._generate_test_report(test_results)

        # 生成故障排除指南
        docs["troubleshooting.md"] = self._generate_troubleshooting(roadmap)

        # 写入文件
        os.makedirs(output_dir, exist_ok=True)
        for filename, content in docs.items():
            filepath = os.path.join(output_dir, filename)
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(content)

        return {os.path.join(output_dir, k): v for k, v in docs.items()}

    def _generate_readme(
        self, roadmap: Dict[str, Any], code_files: Dict[str, str]
    ) -> str:
        """生成项目说明文档"""
        project_name = roadmap.get("project_name", "嵌入式项目")
        description = roadmap.get("description", "")
        hardware = roadmap.get("hardware_list", [])
        phases = roadmap.get("phases", [])
        estimated_days = roadmap.get("estimated_days", 0)
        total_cost = roadmap.get("total_cost", 0)

        lines = [
            f"# {project_name}",
            "",
            "## 项目简介",
            "",
            description,
            "",
            "## 系统架构",
            "",
            "```mermaid",
            "graph TD",
            "    A[传感器数据采集] --> B[数据处理]",
            "    B --> C[本地显示]",
            "    B --> D[云端上传]",
            "    D --> E[Web 监控]",
            "```",
            "",
            "## 硬件清单",
            "",
            "| 序号 | 名称 | 型号 | 数量 | 单价 | 小计 |",
            "|------|------|------|------|------|------|",
        ]

        for i, item in enumerate(hardware, 1):
            name = item.get("name", "")
            category = item.get("category", "")
            quantity = item.get("quantity", 1)
            price = item.get("price", 0)
            subtotal = quantity * price
            lines.append(f"| {i} | {category} | {name} | {quantity} | ¥{price} | ¥{subtotal} |")

        lines.extend(
            [
                "",
                f"**预估总成本**: ¥{total_cost}",
                "",
                "## 开发计划",
                "",
                f"**预估开发周期**: {estimated_days} 天",
                "",
            ]
        )

        for phase in phases:
            phase_name = phase.get("name", "")
            duration = phase.get("duration", "")
            tasks = phase.get("tasks", [])

            lines.extend(
                [
                    f"### {phase_name} ({duration})",
                    "",
                ]
            )

            for task in tasks:
                task_name = task.get("name", "")
                lines.append(f"- [ ] {task_name}")

            lines.append("")

        # 添加代码结构说明
        lines.extend(
            [
                "## 代码结构",
                "",
                "```",
            ]
        )

        for filename in sorted(code_files.keys()):
            lines.append(f"├── {filename}")

        lines.extend(
            [
                "```",
                "",
                "## 快速开始",
                "",
                "### 环境准备",
                "",
                "1. 安装 Arduino IDE 或 PlatformIO",
                "2. 安装所需库:",
                "   ```bash",
                "   pio lib install \"DHT sensor library\"",
                "   pio lib install \"BH1750\"",
                "   pio lib install \"Adafruit SSD1306\"",
                "   ```",
                "",
                "### 编译烧录",
                "",
                "```bash",
                "# 使用 PlatformIO",
                "pio run -t upload",
                "",
                "# 使用 Arduino IDE",
                "# 打开 main.ino，选择开发板，点击上传",
                "```",
                "",
                "### 运行演示",
                "",
                "1. 连接硬件",
                "2. 上电启动",
                "3. 打开串口监视器 (115200 baud)",
                "4. 观察数据输出",
                "",
                "## 许可证",
                "",
                "MIT License",
            ]
        )

        return "\n".join(lines)

    def _generate_wiring(self, hardware: List[Dict]) -> str:
        """生成接线图文档"""
        lines = [
            "# 接线图",
            "",
            "## 硬件连接说明",
            "",
            "### 主控板",
            "",
        ]

        # 按类别分组
        sensors = [h for h in hardware if h.get("category") == "sensor"]
        displays = [h for h in hardware if h.get("category") == "display"]
        mcus = [h for h in hardware if h.get("category") == "mcu"]

        if mcus:
            mcu = mcus[0]
            lines.extend(
                [
                    f"**{mcu.get('name', 'MCU')}** 引脚分配:",
                    "",
                    "| 引脚 | 功能 | 连接目标 |",
                    "|------|------|---------|",
                    "| GPIO21 | SDA | I2C 传感器",
                    "| GPIO22 | SCL | I2C 传感器",
                    "| GPIO4 | DATA | DHT22",
                    "| GPIO2 | LED | 状态指示",
                    "| GND | GND | 公共地",
                    "| 3.3V | VCC | 传感器供电",
                    "",
                ]
            )

        if sensors:
            lines.extend(
                [
                    "### 传感器连接",
                    "",
                ]
            )

            for sensor in sensors:
                name = sensor.get("name", "")
                interface = sensor.get("interface", "")

                if "DHT" in name:
                    lines.extend(
                        [
                            f"**{name}** (温湿度传感器):",
                            "",
                            "| DHT22 引脚 | 连接 |",
                            "|------------|------|",
                            "| VCC | 3.3V |",
                            "| DATA | GPIO4 |",
                            "| GND | GND |",
                            "",
                        ]
                    )
                elif "BH1750" in name:
                    lines.extend(
                        [
                            f"**{name}** (光照传感器):",
                            "",
                            "| BH1750 引脚 | 连接 |",
                            "|-------------|------|",
                            "| VCC | 3.3V |",
                            "| GND | GND |",
                            "| SDA | GPIO21 |",
                            "| SCL | GPIO22 |",
                            "| ADDR | GND |",
                            "",
                        ]
                    )
                elif "MPU6050" in name:
                    lines.extend(
                        [
                            f"**{name}** (六轴 IMU):",
                            "",
                            "| MPU6050 引脚 | 连接 |",
                            "|-------------|------|",
                            "| VCC | 3.3V |",
                            "| GND | GND |",
                            "| SDA | GPIO21 |",
                            "| SCL | GPIO22 |",
                            "| INT | GPIO15 |",
                            "",
                        ]
                    )

        if displays:
            lines.extend(
                [
                    "### 显示屏连接",
                    "",
                ]
            )

            for display in displays:
                name = display.get("name", "")
                if "SSD1306" in name:
                    lines.extend(
                        [
                            f"**{name}** (OLED 显示屏):",
                            "",
                            "| SSD1306 引脚 | 连接 |",
                            "|-------------|------|",
                            "| VCC | 3.3V |",
                            "| GND | GND |",
                            "| SDA | GPIO21 |",
                            "| SCL | GPIO22 |",
                            "",
                        ]
                    )

        # 添加接线图 (Mermaid)
        lines.extend(
            [
                "## 接线示意图",
                "",
                "```mermaid",
                "graph LR",
                "    subgraph ESP32",
                "        D21[GPIO21 - SDA]",
                "        D22[GPIO22 - SCL]",
                "        D4[GPIO4]",
                "        GND[GND]",
                "        VIN[3.3V]",
                "    end",
                "",
            ]
        )

        if sensors:
            lines.append("    subgraph Sensors")
            for sensor in sensors:
                name = sensor.get("name", "").upper()
                lines.append(f"        {name}[{name}]")
            lines.append("    end")

        lines.extend(
            [
                "",
                "    VIN --> Sensors",
                "    D21 --> Sensors",
                "    D22 --> Sensors",
                "    GND --> Sensors",
                "```",
                "",
                "## 注意事项",
                "",
                "1. **电源**: 所有传感器使用 3.3V 供电，切勿接 5V",
                "2. **I2C**: 确保 SDA/SCL 线连接正确",
                "3. **上拉电阻**: I2C 总线需要 4.7K 上拉电阻",
                "4. **焊接**: 注意焊接质量，避免虚焊",
            ]
        )

        return "\n".join(lines)

    def _generate_demo_guide(
        self, roadmap: Dict[str, Any], code_files: Dict[str, str]
    ) -> str:
        """生成演示指南"""
        project_name = roadmap.get("project_name", "嵌入式项目")

        lines = [
            f"# {project_name} - 演示指南",
            "",
            "## 演示准备",
            "",
            "### 硬件准备",
            "",
            "1. 检查所有元器件是否齐全",
            "2. 按照接线图连接硬件",
            "3. 确认无短路或虚焊",
            "",
            "### 软件准备",
            "",
            "1. 安装 Arduino IDE 或 PlatformIO",
            "2. 安装所需库文件",
            "3. 上传代码到开发板",
            "",
            "### 测试工具",
            "",
            "- 串口监视器 (115200 baud)",
            "- 万用表 (可选)",
            "- 示波器 (可选)",
            "",
            "## 演示流程",
            "",
            "### Step 1: 系统启动",
            "",
            "1. 给开发板上电",
            "2. 观察 LED 状态指示",
            "3. 打开串口监视器",
            "4. 等待系统初始化完成",
            "",
            "**预期输出**:",
            "```",
            "[INFO] System starting...",
            "[INFO] DHT sensor initialized",
            "[INFO] BH1750 sensor initialized",
            "[INFO] WiFi connected",
            "[INFO] IP: 192.168.1.100",
            "[INFO] System initialized",
            "```",
            "",
            "### Step 2: 数据采集",
            "",
            "1. 观察传感器数据输出",
            "2. 验证数据合理性:",
            "   - 温度: 20-30°C (室温)",
            "   - 湿度: 40-70% (正常湿度)",
            "   - 光照: 100-1000 lux (室内)",
            "",
            "**预期输出**:",
            "```",
            "[DATA] Temp: 25.5°C, Hum: 60.2%, Light: 350.0lux",
            "[DATA] Temp: 25.6°C, Hum: 60.1%, Light: 345.0lux",
            "```",
            "",
            "### Step 3: 数据上传",
            "",
            "1. 确认 WiFi 连接成功",
            "2. 观察数据上传日志",
            "3. 检查云端数据接收",
            "",
            "**预期输出**:",
            "```",
            "[INFO] HTTP Response: 200",
            "[INFO] Data uploaded successfully",
            "```",
            "",
            "### Step 4: 显示界面",
            "",
            "1. 观察 OLED 显示内容",
            "2. 验证数据显示正确",
            "3. 测试界面刷新",
            "",
            "### Step 5: 异常处理",
            "",
            "1. **传感器断开测试**:",
            "   - 断开某个传感器",
            "   - 观察错误提示",
            "   - 恢复连接后自动重连",
            "",
            "2. **WiFi 断开测试**:",
            "   - 关闭 WiFi 热点",
            "   - 观察重连机制",
            "   - 恢复后自动连接",
            "",
            "3. **长时间运行测试**:",
            "   - 持续运行 1 小时",
            "   - 监控内存使用",
            "   - 检查是否有内存泄漏",
            "",
            "## 常见问题",
            "",
            "### Q1: 传感器读数异常",
            "",
            "- 检查接线是否正确",
            "- 确认传感器供电正常",
            "- 检查 I2C 地址是否冲突",
            "",
            "### Q2: WiFi 连接失败",
            "",
            "- 确认 SSID 和密码正确",
            "- 检查 WiFi 信号强度",
            "- 尝试重启开发板",
            "",
            "### Q3: 串口无输出",
            "",
            "- 检查串口波特率设置",
            "- 确认 USB 线连接正常",
            "- 尝试按复位按钮",
            "",
            "## 演示评分标准",
            "",
            "| 项目 | 分值 | 说明 |",
            "|------|------|------|",
            "| 功能完整性 | 40% | 所有功能正常运行 |",
            "| 稳定性 | 20% | 长时间运行无异常 |",
            "| 代码质量 | 20% | 代码规范，注释完整 |",
            "| 文档完整性 | 10% | 文档齐全，说明清晰 |",
            "| 创新性 | 10% | 有创新设计或优化 |",
        ]

        return "\n".join(lines)

    def _generate_api_doc(self, code_files: Dict[str, str]) -> str:
        """生成 API 文档"""
        lines = [
            "# API 文档",
            "",
            "## 传感器 API",
            "",
            "### DHT22 温湿度传感器",
            "",
            "```c",
            "// 初始化传感器",
            "void dht_init();",
            "",
            "// 读取温度 (°C)",
            "float dht_read_temperature();",
            "",
            "// 读取湿度 (%)",
            "float dht_read_humidity();",
            "```",
            "",
            "### BH1750 光照传感器",
            "",
            "```c",
            "// 初始化传感器",
            "void bh1750_init();",
            "",
            "// 读取光照强度 (lux)",
            "float bh1750_read_light();",
            "```",
            "",
            "### MPU6050 六轴 IMU",
            "",
            "```c",
            "// 初始化传感器",
            "void mpu6050_init();",
            "",
            "// 读取加速度和陀螺仪数据",
            "void mpu6050_read(float *ax, float *ay, float *az, float *gx, float *gy, float *gz);",
            "```",
            "",
            "## 通信 API",
            "",
            "### WiFi",
            "",
            "```c",
            "// 初始化 WiFi",
            "void wifi_init();",
            "",
            "// 上传数据",
            "bool upload_data(float temp, float humidity, float light);",
            "```",
            "",
            "## 工具 API",
            "",
            "### 日志",
            "",
            "```c",
            "// 输出日志",
            "void log_message(int level, const char *tag, const char *format, ...);",
            "```",
            "",
            "### 看门狗",
            "",
            "```c",
            "// 初始化看门狗",
            "void watchdog_init(int timeout_ms);",
            "",
            "// 喂狗",
            "void watchdog_reset();",
            "```",
        ]

        return "\n".join(lines)

    def _generate_test_report(self, test_results: Dict[str, Any]) -> str:
        """生成测试报告"""
        total = test_results.get("total", 0)
        passed = test_results.get("passed", 0)
        failed = test_results.get("failed", 0)
        coverage = test_results.get("coverage", 0)

        lines = [
            "# 测试报告",
            "",
            f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            "",
            "## 测试概览",
            "",
            "| 指标 | 数值 |",
            "|------|------|",
            f"| 测试用例总数 | {total} |",
            f"| 通过数量 | {passed} |",
            f"| 失败数量 | {failed} |",
            f"| 通过率 | {passed/total*100 if total > 0 else 0:.1f}% |",
            f"| 代码覆盖率 | {coverage:.1f}% |",
            "",
            "## 测试详情",
            "",
            "### 通过的测试",
            "",
            "| 测试用例 | 执行时间 |",
            "|---------|---------|",
        ]

        # 添加通过的测试
        for test in test_results.get("passed_tests", []):
            lines.append(f"| {test.get('name', '')} | {test.get('duration', 0):.3f}s |")

        lines.extend(
            [
                "",
                "### 失败的测试",
                "",
                "| 测试用例 | 错误信息 |",
                "|---------|---------|",
            ]
        )

        # 添加失败的测试
        for test in test_results.get("failed_tests", []):
            lines.append(f"| {test.get('name', '')} | {test.get('error', '')} |")

        lines.extend(
            [
                "",
                "## 覆盖率报告",
                "",
                "| 文件 | 语句数 | 未覆盖 | 覆盖率 |",
                "|------|--------|--------|--------|",
            ]
        )

        # 添加覆盖率数据
        for file_cov in test_results.get("coverage_files", []):
            lines.append(
                f"| {file_cov.get('file', '')} | "
                f"{file_cov.get('statements', 0)} | "
                f"{file_cov.get('missing', 0)} | "
                f"{file_cov.get('coverage', 0):.1f}% |"
            )

        lines.extend(
            [
                "",
                "## 风险评估",
                "",
                "- [ ] 高风险: 核心功能未测试",
                "- [ ] 中风险: 边界条件未覆盖",
                "- [ ] 低风险: 错误处理不完整",
                "",
                "## 建议",
                "",
                "1. 补充缺失的测试用例",
                "2. 增加边界条件测试",
                "3. 完善错误处理测试",
            ]
        )

        return "\n".join(lines)

    def _generate_troubleshooting(self, roadmap: Dict[str, Any]) -> str:
        """生成故障排除指南"""
        project_type = roadmap.get("project_type", "general")
        hardware = roadmap.get("hardware_list", [])

        lines = [
            "# 故障排除指南",
            "",
            "## 常见问题",
            "",
            "### 1. 编译错误",
            "",
            "#### 错误: 找不到头文件",
            "",
            "```",
            "fatal error: xxx.h: No such file or directory",
            "```",
            "",
            "**解决方案**:",
            "1. 检查库是否安装",
            "2. 检查 include 路径",
            "3. 重新安装库",
            "",
            "#### 错误: 未定义的引用",
            "",
            "```",
            "undefined reference to 'xxx'",
            "```",
            "",
            "**解决方案**:",
            "1. 检查函数是否实现",
            "2. 检查链接库",
            "3. 检查函数签名",
            "",
            "### 2. 烧录错误",
            "",
            "#### 错误: 无法连接开发板",
            "",
            "**解决方案**:",
            "1. 检查 USB 线连接",
            "2. 安装驱动程序",
            "3. 检查串口选择",
            "",
            "#### 错误: 烧录超时",
            "",
            "**解决方案**:",
            "1. 按住 BOOT 按钮重试",
            "2. 降低波特率",
            "3. 检查电源供应",
            "",
            "### 3. 运行时错误",
            "",
            "#### 问题: 传感器无数据",
            "",
            "**排查步骤**:",
            "1. 检查接线",
            "2. 检查 I2C 地址",
            "3. 使用 I2C 扫描程序",
            "4. 检查上拉电阻",
            "",
            "#### 问题: WiFi 连接失败",
            "",
            "**排查步骤**:",
            "1. 确认 SSID/密码正确",
            "2. 检查 WiFi 信号",
            "3. 尝试静态 IP",
            "4. 检查防火墙设置",
            "",
            "#### 问题: 内存溢出",
            "",
            "**排查步骤**:",
            "1. 监控内存使用",
            "2. 减少全局变量",
            "3. 避免动态分配",
            "4. 使用 F() 宏",
            "",
            "### 4. 通信问题",
            "",
            "#### 问题: 串口乱码",
            "",
            "**解决方案**:",
            "1. 检查波特率设置",
            "2. 检查串口线质量",
            "3. 尝试不同波特率",
            "",
            "#### 问题: I2C 通信失败",
            "",
            "**解决方案**:",
            "1. 检查接线",
            "2. 添加上拉电阻",
            "3. 降低时钟频率",
            "",
            "## 调试技巧",
            "",
            "### 使用串口调试",
            "",
            "```c",
            'Serial.println("[DEBUG] Variable value: " + String(value));',
            "```",
            "",
            "### 使用 LED 指示",
            "",
            "```c",
            "digitalWrite(LED_PIN, HIGH);  // 指示某个状态",
            "```",
            "",
            "### 使用断言",
            "",
            "```c",
            "assert(sensor_value > 0);",
            "```",
            "",
            "## 获取帮助",
            "",
            "1. 查看串口日志",
            "2. 检查硬件连接",
            "3. 搜索错误信息",
            "4. 查阅数据手册",
            "5. 提交 Issue",
        ]

        return "\n".join(lines)


if __name__ == "__main__":
    # 测试代码
    engine = DocGenEngine()

    # 模拟数据
    roadmap = {
        "project_name": "智能环境监测系统",
        "description": "基于 ESP32 的环境监测系统",
        "project_type": "environment",
        "hardware_list": [
            {"category": "mcu", "name": "ESP32", "quantity": 1, "price": 35},
            {"category": "sensor", "name": "DHT22", "quantity": 1, "price": 12},
            {"category": "sensor", "name": "BH1750", "quantity": 1, "price": 8},
            {"category": "display", "name": "SSD1306", "quantity": 1, "price": 15},
        ],
        "phases": [
            {
                "name": "硬件准备",
                "duration": "1天",
                "tasks": [{"name": "采购元器件"}],
            }
        ],
        "estimated_days": 4,
        "total_cost": 70,
    }

    code_files = {
        "main.ino": "// main code",
        "sensor_driver.c": "// sensor driver",
    }

    docs = engine.generate_docs(roadmap, code_files, output_dir="test_docs")
    for filepath, content in docs.items():
        print(f"Generated: {filepath}")
