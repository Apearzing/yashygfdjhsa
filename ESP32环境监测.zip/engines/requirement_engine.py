"""
需求解析引擎 - 负责解析项目需求，生成结构化路线图
"""

import json
import uuid
from datetime import datetime
from typing import Any, Dict, List, Optional

import yaml


class RequirementEngine:
    """需求解析引擎"""

    def __init__(self, config_path: str = "config.yaml"):
        """初始化引擎"""
        with open(config_path, "r", encoding="utf-8") as f:
            self.config = yaml.safe_load(f)

        self.platforms = self.config.get("platforms", {})
        self.hardware_db = self._load_hardware_database()

    def _load_hardware_database(self) -> Dict[str, Any]:
        """加载硬件数据库"""
        return {
            "mcu": {
                "esp32": {
                    "name": "ESP32",
                    "vendor": "Espressif",
                    "cores": 2,
                    "flash": "4MB",
                    "wifi": True,
                    "bluetooth": True,
                    "gpio": 34,
                    "price": 35,
                },
                "esp32-s3": {
                    "name": "ESP32-S3",
                    "vendor": "Espressif",
                    "cores": 2,
                    "flash": "8MB",
                    "wifi": True,
                    "bluetooth": True,
                    "gpio": 45,
                    "camera": True,
                    "price": 55,
                },
                "stm32f103": {
                    "name": "STM32F103",
                    "vendor": "ST",
                    "cores": 1,
                    "flash": "128KB",
                    "wifi": False,
                    "gpio": 37,
                    "price": 15,
                },
                "stm32f407": {
                    "name": "STM32F407",
                    "vendor": "ST",
                    "cores": 1,
                    "flash": "1MB",
                    "wifi": False,
                    "gpio": 114,
                    "price": 45,
                },
            },
            "sensors": {
                "dht22": {
                    "name": "DHT22",
                    "type": "温湿度",
                    "interface": "单总线",
                    "voltage": "3.3-5V",
                    "price": 12,
                },
                "bme280": {
                    "name": "BME280",
                    "type": "温湿度气压",
                    "interface": "I2C/SPI",
                    "voltage": "1.8-3.6V",
                    "price": 18,
                },
                "bh1750": {
                    "name": "BH1750",
                    "type": "光照",
                    "interface": "I2C",
                    "voltage": "2.4-3.6V",
                    "price": 8,
                },
                "mq135": {
                    "name": "MQ-135",
                    "type": "空气质量",
                    "interface": "模拟",
                    "voltage": "5V",
                    "price": 15,
                },
                "mpu6050": {
                    "name": "MPU6050",
                    "type": "六轴IMU",
                    "interface": "I2C",
                    "voltage": "2.4-3.6V",
                    "price": 10,
                },
            },
            "displays": {
                "ssd1306": {
                    "name": "SSD1306",
                    "type": "OLED",
                    "size": "0.96寸",
                    "interface": "I2C",
                    "price": 15,
                },
                "st7789": {
                    "name": "ST7789",
                    "type": "TFT",
                    "size": "1.3寸",
                    "interface": "SPI",
                    "price": 25,
                },
            },
            "communication": {
                "esp8266": {
                    "name": "ESP8266",
                    "type": "WiFi",
                    "price": 12,
                },
                "nrf24l01": {
                    "name": "NRF24L01",
                    "type": "2.4G无线",
                    "price": 8,
                },
                "hc05": {
                    "name": "HC-05",
                    "type": "蓝牙",
                    "price": 20,
                },
            },
        }

    def parse_requirement(
        self, project_name: str, description: str, constraints: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """
        解析项目需求，生成路线图

        Args:
            project_name: 项目名称
            description: 项目描述
            constraints: 约束条件

        Returns:
            结构化路线图
        """
        # 分析项目类型
        project_type = self._analyze_project_type(description)

        # 推荐硬件
        hardware = self._recommend_hardware(project_type, constraints)

        # 生成任务列表
        phases = self._generate_phases(project_type, hardware)

        # 构建路线图
        roadmap = {
            "project_id": f"proj_{uuid.uuid4().hex[:8]}",
            "project_name": project_name,
            "description": description,
            "project_type": project_type,
            "created_at": datetime.now().isoformat(),
            "constraints": constraints or {},
            "hardware_list": hardware,
            "phases": phases,
            "estimated_days": self._estimate_days(phases),
            "total_cost": self._calculate_cost(hardware),
            "risks": self._identify_risks(project_type, hardware),
        }

        return roadmap

    def _analyze_project_type(self, description: str) -> str:
        """分析项目类型"""
        keywords = {
            "environment": ["环境", "监测", "温湿度", "光照", "空气质量"],
            "motion": ["平衡", "运动", "电机", "PID", "小车"],
            "smart_home": ["家居", "智能", "控制", "继电器", "开关"],
            "image": ["图像", "摄像头", "拍照", "识别", "显示"],
            "audio": ["音频", "声音", "麦克风", "喇叭", "播放"],
            "weather": ["气象", "天气", "风速", "雨量", "气压"],
        }

        for ptype, kws in keywords.items():
            if any(kw in description for kw in kws):
                return ptype

        return "general"

    def _recommend_hardware(
        self, project_type: str, constraints: Optional[Dict]
    ) -> List[Dict]:
        """推荐硬件"""
        budget = constraints.get("budget", 200) if constraints else 200
        board = constraints.get("board", None) if constraints else None

        hardware = []

        # 推荐主控
        if board:
            mcu_key = board.lower().replace("-", "")
            if mcu_key in self.hardware_db["mcu"]:
                hardware.append(
                    {
                        "category": "mcu",
                        **self.hardware_db["mcu"][mcu_key],
                        "quantity": 1,
                    }
                )
        else:
            # 根据项目类型推荐
            mcu_map = {
                "environment": "esp32",
                "motion": "stm32f407",
                "smart_home": "esp32",
                "image": "esp32-s3",
                "audio": "stm32f407",
                "weather": "esp32",
                "general": "esp32",
            }
            mcu_key = mcu_map.get(project_type, "esp32")
            hardware.append(
                {
                    "category": "mcu",
                    **self.hardware_db["mcu"][mcu_key],
                    "quantity": 1,
                }
            )

        # 推荐传感器
        sensor_map = {
            "environment": ["dht22", "bh1750", "mq135"],
            "motion": ["mpu6050"],
            "smart_home": [],
            "image": [],
            "audio": [],
            "weather": ["dht22", "bme280"],
        }

        for sensor_key in sensor_map.get(project_type, []):
            if sensor_key in self.hardware_db["sensors"]:
                hardware.append(
                    {
                        "category": "sensor",
                        **self.hardware_db["sensors"][sensor_key],
                        "quantity": 1,
                    }
                )

        # 推荐显示器
        if project_type in ["environment", "weather", "image"]:
            hardware.append(
                {
                    "category": "display",
                    **self.hardware_db["displays"]["ssd1306"],
                    "quantity": 1,
                }
            )

        # 过滤超出预算的硬件
        total = sum(item.get("price", 0) * item.get("quantity", 1) for item in hardware)
        if total > budget:
            # 保留必需品，移除可选件
            hardware = [h for h in hardware if h["category"] in ["mcu", "sensor"]]

        return hardware

    def _generate_phases(
        self, project_type: str, hardware: List[Dict]
    ) -> List[Dict]:
        """生成开发阶段"""
        phases = [
            {
                "phase_id": 1,
                "name": "硬件选型与采购",
                "duration": "1天",
                "tasks": [
                    {
                        "task_id": "t1.1",
                        "name": "确认元器件清单",
                        "description": "根据需求确认所有元器件型号和数量",
                        "status": "pending",
                    },
                    {
                        "task_id": "t1.2",
                        "name": "采购元器件",
                        "description": "从供应商处采购所需元器件",
                        "status": "pending",
                    },
                ],
            },
            {
                "phase_id": 2,
                "name": "驱动开发",
                "duration": "2天",
                "tasks": [
                    {
                        "task_id": "t2.1",
                        "name": "初始化工程",
                        "description": "创建项目工程，配置编译环境",
                        "status": "pending",
                    },
                    {
                        "task_id": "t2.2",
                        "name": "编写传感器驱动",
                        "description": "实现各传感器的初始化和数据读取",
                        "status": "pending",
                    },
                    {
                        "task_id": "t2.3",
                        "name": "编写通信驱动",
                        "description": "实现 WiFi/蓝牙等通信功能",
                        "status": "pending",
                    },
                ],
            },
            {
                "phase_id": 3,
                "name": "功能集成",
                "duration": "2天",
                "tasks": [
                    {
                        "task_id": "t3.1",
                        "name": "主程序框架",
                        "description": "实现主循环和任务调度",
                        "status": "pending",
                    },
                    {
                        "task_id": "t3.2",
                        "name": "数据处理",
                        "description": "实现数据采集、处理和存储",
                        "status": "pending",
                    },
                    {
                        "task_id": "t3.3",
                        "name": "显示界面",
                        "description": "实现 OLED/显示屏界面",
                        "status": "pending",
                    },
                ],
            },
            {
                "phase_id": 4,
                "name": "测试验证",
                "duration": "1天",
                "tasks": [
                    {
                        "task_id": "t4.1",
                        "name": "单元测试",
                        "description": "运行所有单元测试用例",
                        "status": "pending",
                    },
                    {
                        "task_id": "t4.2",
                        "name": "集成测试",
                        "description": "运行集成测试，验证整体功能",
                        "status": "pending",
                    },
                    {
                        "task_id": "t4.3",
                        "name": "压力测试",
                        "description": "长时间运行稳定性测试",
                        "status": "pending",
                    },
                ],
            },
            {
                "phase_id": 5,
                "name": "文档与演示",
                "duration": "1天",
                "tasks": [
                    {
                        "task_id": "t5.1",
                        "name": "编写项目文档",
                        "description": "生成项目说明文档和接线图",
                        "status": "pending",
                    },
                    {
                        "task_id": "t5.2",
                        "name": "准备演示",
                        "description": "准备演示脚本和演示环境",
                        "status": "pending",
                    },
                ],
            },
        ]

        return phases

    def _estimate_days(self, phases: List[Dict]) -> int:
        """估算开发天数"""
        total_tasks = sum(len(phase["tasks"]) for phase in phases)
        return max(1, total_tasks // 3)

    def _calculate_cost(self, hardware: List[Dict]) -> float:
        """计算硬件成本"""
        return sum(item.get("price", 0) * item.get("quantity", 1) for item in hardware)

    def _identify_risks(
        self, project_type: str, hardware: List[Dict]
    ) -> List[Dict]:
        """识别潜在风险"""
        risks = [
            {
                "risk_id": "r1",
                "name": "硬件兼容性",
                "level": "medium",
                "mitigation": "提前测试所有传感器与主控的兼容性",
            },
            {
                "risk_id": "r2",
                "name": "时序冲突",
                "level": "medium",
                "mitigation": "合理规划中断优先级，避免时序冲突",
            },
            {
                "risk_id": "r3",
                "name": "内存溢出",
                "level": "low",
                "mitigation": "监控堆栈使用，避免动态内存分配",
            },
        ]

        if project_type == "motion":
            risks.append(
                {
                    "risk_id": "r4",
                    "name": "PID 参数调优",
                    "level": "high",
                    "mitigation": "预留足够的调试时间，使用串口实时监控",
                }
            )

        return risks


if __name__ == "__main__":
    # 测试代码
    engine = RequirementEngine()
    roadmap = engine.parse_requirement(
        project_name="智能环境监测系统",
        description="基于 ESP32 采集温湿度、光照、空气质量数据，通过 WiFi 上传至云平台",
        constraints={"budget": 200, "board": "ESP32"},
    )
    print(json.dumps(roadmap, indent=2, ensure_ascii=False))
